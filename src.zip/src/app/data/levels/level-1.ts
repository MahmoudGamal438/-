import { Level } from '../../core/models/curriculum.model';
import { analogy, code, h, lesson, list, steps, t, tip, warn } from '../helpers';

export const LEVEL_1: Level = {
  id: 'programming-fundamentals',
  number: 1,
  code: 'L1',
  title: 'اساسيات البرمجة',
  titleEn: 'Programming Fundamentals',
  tagline: 'تتعلم تفكر زي المبرمج قبل ما تفتح Angular.',
  color: '#6366f1',
  duration: '١٠–١٤ يوم',
  why: 'Angular سهل نسبيًا لو دماغك فاهمة منطق. وصعب جدًا لو دخلته وانت لسه مش فاهم Variable.',
  beforeYouStart: ['خلصت اساسيات الكمبيوتر', 'VS Code شغال', 'تعرف تفتح Terminal'],
  goals: [
    'تفهم البرمجة كانتظام تعليمات.',
    'تستخدم Variables و Conditions و Loops.',
    'تكسر المسألة لخطوات.',
    'تقرا رسالة Error من غير ما تتوتر.',
    'تعرف فكرة Git.'
  ],
  skillsGained: ['Problem Solving', 'Logic', 'Functions', 'Arrays', 'Debugging basics', 'Git init'],
  nextSkills: ['HTML structure', 'CSS layout'],
  tools: ['VS Code', 'المتصفح Console', 'Git'],
  lessons: [
    lesson(
      'l1-1',
      'what-is-programming',
      'البرمجة تفكير مش حفظ',
      'What is Programming',
      20,
      'الكود لغة تدي بيها اوامر دقيقة لجهاز غبي وسريع.',
      ['تعرف تفرّق بين الفكرة والتنفيذ.', 'تفهم ليه الغموض عدو المبرمج.', 'تكتب خوارزمية بخطوات بشرية.'],
      [
        t('البرمجة مش موهبة غامضة. هي مهارة: تاخد مشكلة، تكسرها لخطوات صغيرة، وتكتب الخطوات دي بلغة الكمبيوتر يفهمها. الغلط مش عيب، الغلط هو طريقة الكمبيوتر يقولك: الخطوة دي مش واضحة.'),
        analogy(
          'وصفة الشاي',
          'لو قلت للكمبيوتر "اعمل شاي"، هيتلخبط. لو قلت: حط ميه، ولع البوتاجاز، استنى الغليان، حط الكيس، استنى ٣ دقايق... دي خوارزمية Algorithm.'
        ),
        list('عقلية المبرمج', [
          'المشكلة تتكسر.',
          'كل خطوة ليها نتيجة واضحة.',
          'بنختبر دايمًا.',
          'بنعيد الكتابة لما نفهم احسن.'
        ])
      ]
    ),
    lesson(
      'l1-2',
      'variables-and-types',
      'Variables و Data Types',
      'Variables and Types',
      24,
      'الصناديق اللي بنحط فيها البيانات.',
      ['تعرف تعلن متغير.', 'تفرق بين string و number و boolean.', 'تفهم ان النوع غلط بيولع اخطاء بعدين في TypeScript.'],
      [
        t('المتغير Variable اسم لصندوق. الصندوق فيه قيمة. القيمة ليها نوع: رقم، نص، صح/غلط. لو خلطت الانواع عشوائي، البرنامج بيكدب عليك بعدين.'),
        code(
          'javascript',
          `const studentName = 'مينا';\nlet score = 80;\nconst passed = score >= 50;\nconsole.log(studentName, score, passed);`
        ),
        list('انواع هتعيش معاها', [
          'string: نصوص.',
          'number: ارقام.',
          'boolean: true / false.',
          'array: قائمة.',
          'object: كائن فيه خصائص.'
        ]),
        tip('const اولًا', 'استخدم const طول ما القيمة مش هتتغير. let لو هتتغير. متبدأش بـ var.')
      ]
    ),
    lesson(
      'l1-3',
      'conditions',
      'Conditions: البرنامج يقرر',
      'Conditions',
      18,
      'if / else هي اساس اي شاشة ذكية.',
      ['تكتب شرط بسيط.', 'تسلسل اكثر من حالة.', 'تتجنب الشروط المتداخلة زيادة عن اللزوم.'],
      [
        code(
          'javascript',
          `const hours = 12;\nif (hours < 4) {\n  console.log('لسه في الاول');\n} else if (hours < 10) {\n  console.log('ماشي كويس');\n} else {\n  console.log('وقت المراجعة');\n}`
        ),
        warn('شرط مركّب زيادة', 'لو عندك ١٠ if جوه بعض، غالبًا المسألة محتاجة تتقسم لدوال اصغر.')
      ]
    ),
    lesson(
      'l1-4',
      'loops',
      'Loops: متكررش الشغل بايدك',
      'Loops',
      20,
      'for و while و for...of.',
      ['تمر على قائمة.', 'تعرف توقف حلقة.', 'تفهم ليه Loop غلط ممكن يعلّق المتصفح.'],
      [
        code(
          'javascript',
          `const lessons = ['HTML', 'CSS', 'JS'];\nfor (const item of lessons) {\n  console.log('ادرس', item);\n}`
        ),
        analogy('العداد', 'اللوب زي ما تعد كوبايات الشاي للضيوف. نفس الحركة، مدخلات مختلفة.')
      ]
    ),
    lesson(
      'l1-5',
      'functions',
      'Functions: سمّي الشغل المتكرر',
      'Functions',
      22,
      'الدالة بتخلي الكود يتقري ويتختبر.',
      ['تكتب دالة بمدخلات ومخرجات.', 'تفهم Return.', 'تكسر المسألة لدوال صغيرة.'],
      [
        code(
          'javascript',
          `function canPass(score) {\n  return score >= 70;\n}\n\nconsole.log(canPass(90));`
        ),
        tip('دالة تعمل حاجة واحدة', 'لو اسم الدالة بقى "اعمل كل حاجة"، اعرف انك محتاج تقسيم.')
      ]
    ),
    lesson(
      'l1-6',
      'arrays-objects',
      'Arrays و Objects',
      'Arrays and Objects',
      22,
      'شكل البيانات اللي Angular هيعيش عليها.',
      ['تبني قائمة دروس.', 'تبني كائن مستخدم.', 'تقرأ قيمة من Object.'],
      [
        code(
          'javascript',
          `const lessonItem = {\n  id: 'l1-6',\n  title: 'Arrays',\n  done: false\n};\n\nconst track = [lessonItem];\nconsole.log(track[0].title);`
        ),
        t('في Angular هتشوف Arrays في @for وكائنات في الخدمات. لو فهمتهم دلوقتي، Templates هتبقى سهلة.')
      ]
    ),
    lesson(
      'l1-7',
      'algorithms-debug',
      'Algorithms و Debugging',
      'Algorithms and Debugging',
      24,
      'ازاي تحل، وازاي تقرا الغلط.',
      ['تكتب خطوات قبل الكود.', 'تستخدم console.log بذكاء.', 'تقرا رسالة الخطأ بهدوء.'],
      [
        steps('طريقة الحل', [
          'افهم المطلوب بجملة واحدة.',
          'اكتب المثال على ورق: مدخل -> مخرج.',
          'قسم لخطوات.',
          'ترجم خطوة خطوة لكود.',
          'اختبر بحالة بسيطة وحالة فارغة.'
        ]),
        code(
          'javascript',
          `function progress(done, total) {\n  if (total === 0) return 0;\n  return Math.round((done / total) * 100);\n}\n\nconsole.log(progress(3, 10));`
        ),
        h('قراءة الاخطاء'),
        t('رسالة الخطأ مش شتيمة. هي عنوان الغلط + مكانه. اقرا السطر الاول، روح للملف والرقم، بص على السطر اللي فوقه. 80% من اخطاء المبتدئ: اسم غلط، قوس ناقص، نوع مش متوقع.')
      ]
    ),
    lesson(
      'l1-8',
      'git-github-start',
      'Git و GitHub من باب البيت',
      'Git and GitHub Basics',
      22,
      'حفظ تاريخ شغلك، مش بس رفع ملفات.',
      ['تعمل repo محلي.', 'تفهم commit.', 'تعرف ليه Git مهم للفريق.'],
      [
        t('Git آلة زمن للكود. كل Commit صورة واضحة للشغل. GitHub مكان تحط فيه الصور دي وتشاركها. من غير Git، اي تجربة غلط ممكن تمسح يوم كامل.'),
        code(
          'bash',
          `git init\ngit add .\ngit commit -m "feat: first learning notes"`
        ),
        tip('رسالة الكوميت', 'اكتب فعل واضح: feat لاضافة، fix لتصليح، docs لتوثيق. متكتبش "تعديلات".')
      ],
      {
        exercise: {
          id: 'l1-ex',
          title: 'حاسبة تقدم بسيطة',
          difficulty: 'easy',
          brief: 'اكتب دالة بتاخد عدد الدروس المخلصة والكلي، وترجع نسبة من 0 لـ 100. لو الكلي صفر ترجع 0.',
          hints: ['احترس من القسمة على صفر.', 'استخدم Math.round.'],
          solution: `function progress(done, total) {\n  if (!total) return 0;\n  return Math.round((done / total) * 100);\n}`
        },
        challenge: {
          id: 'l1-ch',
          title: 'قائمة مهام في الذاكرة',
          brief: 'ابنِ مصفوفة مهام، ودوال: اضافة، تعليم كمكتمل، وعدّ المكتمل.',
          goals: ['Array + Object', 'Functions', 'Condition']
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l1-q1',
      prompt: 'const بتستخدم امتى؟',
      options: ['لما القيمة هتتغير كل شوية', 'لما القيمة ثابتة مش هتتعوض', 'بدل الدوال', 'مع الصور بس'],
      answerIndex: 1,
      explanation: 'const للصناديق اللي مش هتتحط فيها قيمة جديدة.'
    },
    {
      id: 'l1-q2',
      prompt: 'Function ليها فايدة ايه؟',
      options: ['تلوين الصفحة', 'تجميع منطق يتكرر ويتسمى باسم واضح', 'تسريع النت', 'مسح Git'],
      answerIndex: 1,
      explanation: 'الدوال بتنظم الشغل وتخلي الاختبار اسهل.'
    },
    {
      id: 'l1-q3',
      prompt: 'اول حاجة تعملها وانت قصاد Error؟',
      options: ['تقفل الجهاز', 'تمسح المشروع', 'تقرا الرسالة وتحدد الملف والسطر', 'تغير اللغة'],
      answerIndex: 2,
      explanation: 'رسالة الخطأ خريطة. اقراها قبل ما تغير عشوائي.'
    },
    {
      id: 'l1-q4',
      prompt: 'Git مفيد ليه؟',
      options: ['تصميم الشعارات', 'تتبع تاريخ الكود والرجوع لنسخ سابقة', 'تشغيل الفيديوهات', 'زيادة RAM'],
      answerIndex: 1,
      explanation: 'Git سجل تغييرات. اساس شغل أي فريق.'
    }
  ],
  projects: [
    {
      id: 'l1-p1',
      title: 'محرك قرارات التعلم',
      titleEn: 'Study Decision Engine',
      size: 'mini',
      levelId: 'programming-fundamentals',
      duration: 'ساعتين',
      summary: 'برنامج في Console بيسال: ذاكرت كام ساعة؟ ويرد بخطة اليوم.',
      skills: ['Conditions', 'Functions', 'Input logic'],
      features: ['حساب نسبة', 'رسائل تشجيع', 'حالة خاصة للصفر'],
      portfolioValue: 'تمرين منطق، مش مشروع عرض. بس هيثبت التفكير.'
    }
  ]
};
