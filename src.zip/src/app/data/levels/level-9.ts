import { Level } from '../../core/models/curriculum.model';
import { lesson, list, t, tip, warn } from '../helpers';

export const LEVEL_9: Level = {
  id: 'ai-for-developers',
  number: 9,
  code: 'L9',
  title: 'الذكاء الاصطناعي للمبرمجين',
  titleEn: 'AI for Developers',
  tagline: 'AI زميلك في الشغل، مش بديل لدماغك.',
  color: '#06b6d4',
  duration: '٧–١٠ ايام',
  why: 'السوق بقى متوقع انك تستخدم AI بسرعة من غير ما تبقى ناسخ أعمى.',
  beforeYouStart: ['تعرف تقرأ كود Angular', 'عندك مشروع تجرب عليه'],
  goals: [
    'تكتب Prompts مفيدة.',
    'تستخدم AI للفهم مش للنسخ.',
    'تعمل Refactor و Tests بمساعدة.',
    'تعرف حدود الاداة.'
  ],
  skillsGained: ['Prompting', 'AI debugging', 'AI tests', 'Responsible use', 'Docs with AI'],
  nextSkills: ['Job ready habits'],
  tools: ['مساعد كود في المحرر', 'Chat models', 'Docs search'],
  lessons: [
    lesson(
      'l9-1',
      'ai-mindset',
      'العقلية الصح مع AI',
      'AI Mindset',
      18,
      'لو نسخت من غير فهم، هتقع في المقابلة وفي البج.',
      ['تفرق بين التعلم والغش.', 'تخلي AI يشرح قبل ما يكتب.', 'تراجع كل سطر.'],
      [
        warn(
          'خط أحمر',
          'استخدام AI عشان يحل التمرين وانت بتبص للحل وخلاص = صفر مهارة. استخدامه عشان يسألك اسئلة ويراجع فهمك = تسريع تعلم.'
        ),
        list('استخدامات محترمة', [
          'شرح كود قديم.',
          'اقتراح اختبارات.',
          'تسمية أوضح.',
          'مقارنة حلول.',
          'كتابة مسودة README ثم تدقيقك.'
        ])
      ]
    ),
    lesson(
      'l9-2',
      'prompts',
      'Prompts للمبرمج',
      'Prompting',
      20,
      'السياق = الجودة.',
      ['تدي نسخة Angular.', 'تلزق الخطأ كامل.', 'تحدد القيد: Standalone، Signals.'],
      [
        t('برومبت ضعيف: "Angular routing مش شغال". برومبت قوي: "Angular 19 Standalone، المسار learn/:id بيفتح كومبوننت بس الـ input فاضي. الكود فلان. ايه الأسباب المحتملة من غير ما تعيد كتابة المشروع كله؟"')
      ]
    ),
    lesson(
      'l9-3',
      'ai-workflow',
      'AI في دورة الشغل',
      'AI Workflow',
      22,
      'فهم، تصميم، كود، اختبار، مراجعة.',
      ['تعمل خطة قبل الكود.', 'تطلب اختبارات.', 'تعمل review.'],
      [
        tip(
          'طريقة مسار',
          'بعد كل درس اسأل: اشرحلي الفكرة كأني لسه ببدأ، بعدين اختبرني بـ 3 اسئلة، بعدين اديني تمرين من غير حل. الحل بعد ما احاول.'
        ),
        list('الشغل اليومي', [
          'Debugging: الصق الخطأ + الكود المحيط.',
          'Components: اطلب هيكل مش نسخة جاهزة ضخمة.',
          'Tests: ابدأ بحالات الحدود.',
          'Refactor: اطلب مخاطر التغيير.'
        ])
      ]
    )
  ],
  quiz: [
    {
      id: 'l9-q1',
      prompt: 'الاستخدام الصح لـ AI وانت بتتعلم؟',
      options: [
        'ينسخ المشروع كامل',
        'يشرح ويختبر فهمك بعد محاولتك',
        'يكتب الـ CV بس',
        'يقفل التوثيق الرسمي'
      ],
      answerIndex: 1,
      explanation: 'الفهم اولًا، التسريع ثانيًا.'
    }
  ],
  projects: [
    {
      id: 'l9-p1',
      title: 'دفتر برومبتات المطوّر',
      titleEn: 'Dev Prompt Playbook',
      size: 'mini',
      levelId: 'ai-for-developers',
      duration: 'يومين',
      summary: 'جمع 10 برومبتات جاهزة: شرح، اختبار، ريفيو، توثيق، أداء.',
      skills: ['Prompt design', 'Reflection'],
      features: ['Templates', 'Before/after examples'],
      portfolioValue: 'يبين وعيك بأدوات العصر.'
    }
  ]
};
