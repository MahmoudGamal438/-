import { Component, input, signal } from '@angular/core';

@Component({
  selector: 'app-code-block',
  template: `
    <div class="code-wrap">
      <div class="code-bar">
        <span>{{ language() || 'code' }}</span>
        <button type="button" (click)="copy()">{{ copied() ? 'اتنسخ' : 'نسخ' }}</button>
      </div>
      <pre><code>{{ code() }}</code></pre>
    </div>
  `
})
export class CodeBlockComponent {
  readonly code = input('');
  readonly language = input('');
  readonly copied = signal(false);

  async copy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(this.code());
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 1600);
    } catch {
      this.copied.set(false);
    }
  }
}
