import { Level } from '../../core/models/curriculum.model';
import { code, lesson, list, t, tip, warn } from '../helpers';

export const LEVEL_6: Level = {
  id: 'advanced-angular',
  number: 6,
  code: 'L6',
  title: 'Angular المتقدم',
  titleEn: 'Advanced Angular',
  tagline: 'من تطبيق شغال لتطبيق يتصان ويتوسع ويتأمن.',
  color: '#be123c',
  duration: '٢٤–٣٥ يوم',
  why: 'الشركات مش بتدور على حد يعمل Counter. بتدور على حد يفهم Architecture و RxJS و Security.',
  beforeYouStart: ['خلصت اساسيات Angular', 'عندك مشروع صغير شغال', 'فاهم Signals و Routing'],
  goals: [
    'تستخدم RxJS بوعي.',
    'تحمي المسارات بـ Guards.',
    'تبني Interceptors.',
    'تقسم التطبيق Lazy.',
    'تفهم State و Performance و Testing.'
  ],
  skillsGained: [
    'RxJS',
    'Guards',
    'Interceptors',
    'Lazy Loading',
    'State Management',
    'Testing',
    'Security',
    'Performance'
  ],
  nextSkills: ['UI libraries', 'Design systems'],
  tools: ['Angular DevTools', 'Jasmine/Karma أو Vitest حسب الإعداد', 'RxJS'],
  lessons: [
    lesson(
      'l6-1',
      'rxjs',
      'RxJS من غير رعب',
      'RxJS',
      30,
      'Streams للأحداث المتصلة: بحث، sockets، تعدد طلبات.',
      ['تفهم Observable.', 'تعرف switchMap vs mergeMap.', 'تعرف امتى Signals تكفي.'],
      [
        t('مش كل حاجة RxJS. Signals ممتازة لحالة الواجهة. RxJS ممتاز للزمن: كتابة المستخدم، إعادة المحاولة، دمج مصادر. الغلط انك تحول كل click لـ Subject من غير داعي.'),
        code(
          'typescript',
          `query = signal('');\nresults = toSignal(\n  toObservable(this.query).pipe(\n    debounceTime(250),\n    distinctUntilChanged(),\n    switchMap(q => this.api.search(q))\n  ),\n  { initialValue: [] }\n);`
        )
      ]
    ),
    lesson(
      'l6-2',
      'auth-guards',
      'Authentication و Guards',
      'Auth and Guards',
      26,
      'مش كل صفحة مفتوحة للشارع.',
      ['تعمل CanActivate.', 'تخزن توكن بأمان مبدئي.', 'تعمل صفحة 403 لطيفة.'],
      [
        code(
          'typescript',
          `export const authGuard: CanActivateFn = () => {\n  const auth = inject(AuthService);\n  const router = inject(Router);\n  return auth.isLoggedIn() ? true : router.createUrlTree(['/login']);\n};`
        )
      ]
    ),
    lesson(
      'l6-3',
      'interceptors',
      'Interceptors',
      'HTTP Interceptors',
      22,
      'مكان واحد للتوكن وللخطأ العام.',
      ['تضيف Authorization header.', 'تلتقط 401.', 'متعملش سحر غامض زيادة.'],
      [
        code(
          'typescript',
          `export const authInterceptor: HttpInterceptorFn = (req, next) => {\n  const token = inject(AuthService).token();\n  const cloned = token\n    ? req.clone({ setHeaders: { Authorization: \`Bearer \${token}\` } })\n    : req;\n  return next(cloned);\n};`
        )
      ]
    ),
    lesson(
      'l6-4',
      'architecture',
      'Architecture للمشاريع الكبيرة',
      'Angular Architecture',
      28,
      'core / shared / features / data.',
      ['تعرف حدود كل طبقة.', 'تمنع Feature تمسك Feature تانية بعشوائية.', 'تخلي المحتوى Data مش UI.'],
      [
        list('هيكل مسار', [
          'core: خدمات جوهرية وموديلات.',
          'shared: كومبوننتات عامة.',
          'features: صفحات lazy.',
          'data: المنهج والمحتوى قابل للزيادة.'
        ]),
        tip('قابلية التوسع', 'إضافة مستوى جديد مفروض تبقى ملف بيانات مش إعادة اختراع الصفحات.')
      ]
    ),
    lesson(
      'l6-5',
      'perf-security-test',
      'Performance و Security و Testing',
      'Perf, Security, Testing',
      30,
      'التطبيق السريع الآمن المختبر.',
      ['تستخدم OnPush / signals.', 'تعرف XSS في القوالب.', 'تكتب اختبار خدمة.'],
      [
        warn('innerHTML', 'متلزقش HTML جاي من المستخدم. Angular بينظف القوالب افتراضيًا، متكسرش الحماية.'),
        code(
          'typescript',
          `describe('ProgressService', () => {\n  it('returns 0 when empty', () => {\n    const s = new ProgressService(new MemoryStorage());\n    expect(s.percent('x')).toBe(0);\n  });\n});`
        ),
        t('Lazy Loading بيقسم الباكتات. track في @for بيمنع إعادة رسم عبثية. صور بحجم مناسب. Change detection مش خصم لو الحالة واضحة.')
      ],
      {
        challenge: {
          id: 'l6-ch',
          title: 'طبقة API محمية',
          brief: 'Login وهمي، Guard، Interceptor، وصفحة بروفايل.',
          goals: ['Auth flow', 'Protected routes', 'Error interceptor']
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l6-q1',
      prompt: 'switchMap مناسب لامتى في البحث؟',
      options: [
        'عشان نشغل كل الطلبات مع بعض',
        'نلغي الطلب القديم ونكمل بآخر حرف كتبه المستخدم',
        'نوقف Angular',
        'نبدل الثيم'
      ],
      answerIndex: 1,
      explanation: 'البحث الحي يحتاج إلغاء النتائج القديمة.'
    },
    {
      id: 'l6-q2',
      prompt: 'CanActivate بيعمل ايه؟',
      options: ['يغير اللون', 'يقرر الدخول للمسار قبل العرض', 'يثبت npm', 'يحذف الـ cache'],
      answerIndex: 1,
      explanation: 'الحارس بوابة المسار.'
    }
  ],
  projects: [
    {
      id: 'l6-p1',
      title: 'لوحة تعلم بفريق',
      titleEn: 'Team Learning Board',
      size: 'medium',
      levelId: 'advanced-angular',
      duration: '١٠ ايام',
      summary: 'تطبيق فيه تسجيل، صلاحيات، دروس محمية، وبحث debounce.',
      skills: ['Guards', 'RxJS', 'Architecture', 'HTTP'],
      features: ['Login', 'Role guard', 'Search', 'Lazy routes'],
      portfolioValue: 'قريب من شغل الشركات الصغيرة.'
    }
  ]
};
