import { Component, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';

@Component({
  selector: 'app-bookmarks-page',
  imports: [RouterLink],
  template: `
    <section class="page-head">
      <div>
        <h1>المحفوظات</h1>
        <p>الدروس اللي حابب ترجع لها.</p>
      </div>
    </section>
    <div class="lesson-list">
      @for (item of items(); track item.lesson.id) {
        <a class="lesson-row" [routerLink]="['/learn', item.level.id, item.lesson.slug]">
          <div>
            <h3>{{ item.lesson.title }}</h3>
            <p>{{ item.level.title }}</p>
          </div>
        </a>
      } @empty {
        <p class="muted">لسه ما فيش محفوظات.</p>
      }
    </div>
  `
})
export class BookmarksPage {
  private readonly progress = inject(ProgressService);
  private readonly curriculum = inject(CurriculumService);
  readonly items = computed(() => {
    const ids = this.progress.bookmarks();
    return this.curriculum.allLessons().filter(row => ids.includes(row.lesson.id));
  });
}
