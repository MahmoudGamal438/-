import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ArabicNumPipe } from '../../shared/pipes/arabic-num.pipe';

@Component({
  selector: 'app-home-page',
  imports: [RouterLink, ArabicNumPipe],
  templateUrl: './home.page.html'
})
export class HomePage {
  readonly curriculum = inject(CurriculumService);
  readonly progress = inject(ProgressService);
  readonly stats = this.curriculum.stats();
}
