import { Component, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ArabicNumPipe } from '../../shared/pipes/arabic-num.pipe';

@Component({
  selector: 'app-level-page',
  imports: [RouterLink, ArabicNumPipe],
  templateUrl: './level.page.html'
})
export class LevelPage {
  private readonly route = inject(ActivatedRoute);
  private readonly curriculum = inject(CurriculumService);
  readonly progress = inject(ProgressService);
  private readonly id = toSignal(this.route.paramMap.pipe(map(p => p.get('levelId') ?? '')), { initialValue: '' });
  readonly level = computed(() => this.curriculum.getLevel(this.id()));
}
