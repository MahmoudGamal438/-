import { Level } from '../core/models/curriculum.model';
import { LEVEL_0 } from './levels/level-0';
import { LEVEL_1 } from './levels/level-1';
import { LEVEL_2 } from './levels/level-2';
import { LEVEL_3 } from './levels/level-3';
import { LEVEL_4 } from './levels/level-4';
import { LEVEL_5 } from './levels/level-5';
import { LEVEL_6 } from './levels/level-6';
import { LEVEL_7 } from './levels/level-7';
import { LEVEL_8 } from './levels/level-8';
import { LEVEL_9 } from './levels/level-9';
import { LEVEL_10 } from './levels/level-10';

export const LEVELS: Level[] = [
  LEVEL_0,
  LEVEL_1,
  LEVEL_2,
  LEVEL_3,
  LEVEL_4,
  LEVEL_5,
  LEVEL_6,
  LEVEL_7,
  LEVEL_8,
  LEVEL_9,
  LEVEL_10
];

export const PLATFORM = {
  name: 'مسار',
  nameEn: 'Masar',
  slogan: 'من صفر الكمبيوتر لحد Angular Developer جاهز للشغل',
  dialectNote: 'الشرح بالمصري البسيط، والمصطلحات التقنية بالإنجليزي جنبها.',
  afterAngular: [
    'Git في فريق',
    'قراءة Documentation',
    'أساسيات Backend للمفهوم',
    'Deployment',
    'Testing',
    'Portfolio + CV + Interviews'
  ]
};
