import { Level } from '../../core/models/curriculum.model';
import { lesson, list, steps, t } from '../helpers';

export const LEVEL_8: Level = {
  id: 'real-world-projects',
  number: 8,
  code: 'L8',
  title: 'مشاريع حقيقية',
  titleEn: 'Real-World Projects',
  tagline: 'تبني شغل يتتحط في Portfolio ويتناقش في المقابلة.',
  color: '#10b981',
  duration: '٣٠–٤٥ يوم',
  why: 'الشركات بتسأل: عملت ايه؟ مش: خلصت بلايليست كام ساعة؟',
  beforeYouStart: ['Angular fundamentals + advanced', 'GitHub حساب نظيف', 'تقدر تقرأ docs'],
  goals: [
    'تنفذ مشروع كامل من تصميم لفكرة نشر.',
    'تكتب README محترم.',
    'تكسر الشغل لـ issues.',
    'تعمل Code review لنفسك.'
  ],
  skillsGained: ['Product thinking', 'Architecture in practice', 'README', 'Deployment basics', 'Portfolio storytelling'],
  nextSkills: ['AI-assisted workflow', 'Job hunt'],
  tools: ['Angular', 'GitHub', 'أي API عام أو Mock'],
  lessons: [
    lesson(
      'l8-1',
      'how-to-build',
      'ازاي تبني مشروع زي الشركات',
      'Building Like a Team',
      22,
      'مش تبدأ كود من اول دقيقة.',
      ['تكتب نطق المشكلة.', 'ترسم شاشات.', 'تقسم مهام.'],
      [
        steps('قبل اول Commit', [
          'جملة القيمة: المشروع بيعمل ايه لمين.',
          'قائمة شاشات.',
          'موديل البيانات.',
          'مخاطر (Auth، فلتر، باجينيشن).',
          'تعريف Done.'
        ]),
        t('المشروع الكبير بيتاكل زي الاكل: شريحة شريحة. Mini ثم Medium ثم Capstone.')
      ]
    ),
    lesson(
      'l8-2',
      'portfolio-quality',
      'جودة الـ Portfolio',
      'Portfolio Quality',
      18,
      'الكود النظيف يبان من الـ README.',
      ['تكتب سيناريو تشغيل.', 'تحط سكرين شوت.', 'توثق قرارات.'],
      [
        list('README مش pref', [
          'المشكلة.',
          'الحل.',
          'Stack.',
          'Architecture باختصار.',
          'ازاي تشغله.',
          'صور.',
          'اللي هتعمله بعدين.'
        ])
      ]
    )
  ],
  quiz: [
    {
      id: 'l8-q1',
      prompt: 'اول خطوة في مشروع حقيقي؟',
      options: ['تثبيت عشر مكتبات', 'فهم المشكلة ورسم الشاشات', 'شراء دومين', 'كتابة CV'],
      answerIndex: 1,
      explanation: 'من غير فهم، الكود تخمين.'
    }
  ],
  projects: [
    {
      id: 'l8-p1',
      title: 'منصة كورسات مصغرة',
      titleEn: 'Mini LMS',
      size: 'capstone',
      levelId: 'real-world-projects',
      duration: '٣ اسابيع',
      summary: 'مستويات، دروس، تقدم، اختبارات، حساب مستخدم. قريب جدًا من المنصة دي.',
      skills: ['Full Angular app', 'Auth', 'State', 'UX'],
      features: ['Catalog', 'Player', 'Quiz', 'Progress', 'Dark mode'],
      portfolioValue: 'المشروع الاساسي في التقديم.'
    },
    {
      id: 'l8-p2',
      title: 'لوحة وظائف Front-End',
      titleEn: 'Job Board',
      size: 'medium',
      levelId: 'real-world-projects',
      duration: '١٠ ايام',
      summary: 'تصفح وظائف، فلترة بـ Angular skills، حفظ وظائف، تقديم وهمي.',
      skills: ['Filters', 'Routing', 'Forms', 'UX'],
      features: ['Search', 'Saved jobs', 'Apply form'],
      portfolioValue: 'فكرة قريبة من السوق.'
    },
    {
      id: 'l8-p3',
      title: 'متتبع مصاريف شخصي',
      titleEn: 'Expense Tracker',
      size: 'medium',
      levelId: 'real-world-projects',
      duration: 'اسبوع',
      summary: 'CRUD، Charts، فئات، تصدير JSON.',
      skills: ['Forms', 'Charts', 'Local state'],
      features: ['Categories', 'Charts', 'Export'],
      portfolioValue: 'يوضح CRUD كامل.'
    }
  ]
};
