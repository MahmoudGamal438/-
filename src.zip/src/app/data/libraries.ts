import { LibraryItem } from '../core/models/curriculum.model';

export const LIBRARIES: LibraryItem[] = [
  {
    id: 'angular-material',
    name: 'Angular Material',
    category: 'UI Kit',
    when: 'لوحات تحكم، منتجات داخلية، محتاج Accessibility جاهز ومكونات ناضجة.',
    vs: 'اثقل من CSS خالص، وأقل حرية بصرية من Tailwind لو عندك هوية خاصة.',
    how: 'ادخل من المكوّن الرسمي، استخدم الثيم، ومتكسرش الـ density من غير سبب.'
  },
  {
    id: 'cdk',
    name: 'Angular CDK',
    category: 'Primitives',
    when: 'عايز Overlay، Drag-Drop، a11y من غير شكل Material الكامل.',
    vs: 'مش UI جاهز، هو لبنات.',
    how: 'ابنه فوقه نظامك. مناسب لو هتبني Design system.'
  },
  {
    id: 'tailwind',
    name: 'Tailwind CSS',
    category: 'Styling',
    when: 'عندك تصميم مخصص وعايز سرعة من غير ملفات CSS متضخمة عشوائي.',
    vs: 'مش مكونات. هتبني الزرار بنفسك أو تستخدم مكتبة رأسًا.',
    how: 'مع Angular خليه في طبقات واضحة، وحدد tokens للألوان.'
  },
  {
    id: 'bootstrap',
    name: 'Bootstrap',
    category: 'UI Kit',
    when: 'MVP سريع، لاندنج، فريق متعود على الكلاسات الجاهزة.',
    vs: 'شكل مألوف يبان "بوتستراب" لو معملتش تخصيص. مع Angular خليك في غلاف مدعوم.',
    how: 'استخدمه للهيكل السريع، وبعدين انحت الهوية.'
  },
  {
    id: 'ng-bootstrap',
    name: 'ng-bootstrap',
    category: 'UI Kit',
    when: 'عايز Bootstrap مع Angular من غير jQuery.',
    vs: 'مرتبط بفلسفة Bootstrap.',
    how: 'ممتاز للنماذج الداخلية السريعة.'
  },
  {
    id: 'lucide',
    name: 'Lucide / Material Icons',
    category: 'Icons',
    when: 'أي واجهة. الأيقونات لغة. اتسق على عائلة واحدة.',
    vs: 'متخلطش ٥ عائلات في شاشة.',
    how: 'حدد مقاس وstroke واحد.'
  },
  {
    id: 'charts',
    name: 'Chart.js / ECharts',
    category: 'Charts',
    when: 'تقدم، مبيعات، إحصائيات تعلم.',
    vs: 'Chart.js أبسط. ECharts أغنى وأثقل.',
    how: 'غلّف الرسم في كومبوننت، ومتحطش المكتبة في كل صفحة.'
  },
  {
    id: 'ngrx',
    name: 'NgRx',
    category: 'State',
    when: 'حالة معقدة، أحداث كتير، فرق كبيرة، تحتاج time-travel.',
    vs: 'Signals + خدمات تكفي أغلب التطبيقات المتوسطة.',
    how: 'دخلها متأخر. التكلفة ذهنية.'
  },
  {
    id: 'transloco',
    name: 'Transloco / ngx-translate',
    category: 'i18n',
    when: 'عربي وإنجليزي في نفس المنتج.',
    vs: 'لو المحتوى ثابت زي منصة تعليم، بيانات عربية كافية في البداية.',
    how: 'افصل النصوص عن القوالب بدري لو هتتوسع.'
  },
  {
    id: 'pwa',
    name: 'Angular Service Worker',
    category: 'PWA',
    when: 'عايز المنصة تتفتح أوفلاين للدروس المحفوظة.',
    vs: 'تعقيد كاش. مش أول أولوية للمتعلم.',
    how: 'بعد ما المنتج يستقر.'
  }
];
