import { Component, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ThemeService } from '../../core/services/theme.service';
import { ArabicNumPipe } from '../pipes/arabic-num.pipe';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ArabicNumPipe],
  template: `
    <div class="shell" [class.nav-open]="menuOpen()">
      <header class="topbar">
        <div class="topbar-row">
          <a routerLink="/" class="brand" (click)="closeMenu()">
            <span class="logo">مسار</span>
            <span class="brand-sub">Angular Track</span>
          </a>

          <nav class="desktop-nav" aria-label="التنقل الرئيسي">
            <a routerLink="/roadmap" routerLinkActive="active">الخريطة</a>
            <a routerLink="/projects" routerLinkActive="active">المشاريع</a>
            <a routerLink="/libraries" routerLinkActive="active">المكتبات</a>
            <a routerLink="/ai" routerLinkActive="active">AI</a>
            <a routerLink="/job-ready" routerLinkActive="active">سوق العمل</a>
            <a routerLink="/bookmarks" routerLinkActive="active">محفوظات</a>
          </nav>

          <div class="top-actions">
            <div class="search desktop-search">
              <input
                type="search"
                placeholder="دور على درس أو مستوى..."
                [value]="query()"
                (input)="query.set($any($event.target).value)"
              />
              @if (query().trim().length > 1) {
                <div class="search-panel">
                  @for (hit of hits(); track hit.link + hit.title) {
                    <a [routerLink]="hit.link" (click)="clearSearch()">
                      <small>{{ hit.kind }}</small>
                      <strong>{{ hit.title }}</strong>
                      <span>{{ hit.subtitle }}</span>
                    </a>
                  } @empty {
                    <p class="muted">مفيش نتيجة قريبة.</p>
                  }
                </div>
              }
            </div>
            <button class="icon-btn" type="button" (click)="theme.toggle()">
              {{ theme.isDark() ? 'نهاري' : 'ليلي' }}
            </button>
            <a class="progress-chip" routerLink="/roadmap" (click)="closeMenu()">
              {{ progress.overallPercent() | arNum }}%
            </a>
            <button
              class="hamburger"
              type="button"
              [attr.aria-expanded]="menuOpen()"
              aria-controls="mobile-nav"
              aria-label="قائمة التنقل"
              (click)="menuOpen.set(!menuOpen())"
            >
              <span></span>
              <span></span>
              <span></span>
            </button>
          </div>
        </div>

        <nav id="mobile-nav" class="mobile-nav" [class.open]="menuOpen()" aria-label="تنقل الشاشات المتوسطة والصغيرة">
          <a routerLink="/roadmap" routerLinkActive="active" (click)="closeMenu()">الخريطة</a>
          <a routerLink="/projects" routerLinkActive="active" (click)="closeMenu()">المشاريع</a>
          <a routerLink="/libraries" routerLinkActive="active" (click)="closeMenu()">المكتبات</a>
          <a routerLink="/ai" routerLinkActive="active" (click)="closeMenu()">AI</a>
          <a routerLink="/job-ready" routerLinkActive="active" (click)="closeMenu()">سوق العمل</a>
          <a routerLink="/bookmarks" routerLinkActive="active" (click)="closeMenu()">محفوظات</a>
        </nav>
      </header>

      <main class="main">
        <router-outlet />
      </main>
      <footer class="footer">
        <p>مسار — منصة عربية بتاخدك من صفر الكمبيوتر لحد Angular Developer جاهز للشغل.</p>
        <p class="muted">الشرح بالمصري البسيط، والمصطلحات التقنية بالإنجليزي.</p>
      </footer>
    </div>
  `
})
export class ShellComponent {
  readonly theme = inject(ThemeService);
  readonly progress = inject(ProgressService);
  private readonly curriculum = inject(CurriculumService);
  private readonly router = inject(Router);
  readonly query = signal('');
  readonly menuOpen = signal(false);

  constructor() {
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(() => this.closeMenu());
  }

  hits() {
    return this.curriculum.search(this.query());
  }

  closeMenu(): void {
    this.menuOpen.set(false);
  }

  clearSearch(): void {
    this.query.set('');
    this.closeMenu();
  }
}
