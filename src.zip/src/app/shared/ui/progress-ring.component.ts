import { Component, computed, input } from '@angular/core';
import { ArabicNumPipe } from '../pipes/arabic-num.pipe';

@Component({
  selector: 'app-progress-ring',
  imports: [ArabicNumPipe],
  template: `
    <div class="ring" [style.--p]="value()">
      <span>{{ value() | arNum }}%</span>
    </div>
  `
})
export class ProgressRingComponent {
  readonly value = input(0);
  readonly dash = computed(() => this.value());
}
