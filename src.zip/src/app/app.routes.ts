import { Routes } from '@angular/router';
import { ShellComponent } from './shared/layout/shell.component';

export const routes: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      {
        path: '',
        loadComponent: () => import('./features/home/home.page').then(m => m.HomePage),
        title: 'مسار | من الصفر لـ Angular Developer'
      },
      {
        path: 'roadmap',
        loadComponent: () => import('./features/roadmap/roadmap.page').then(m => m.RoadmapPage),
        title: 'الخريطة التعليمية | مسار'
      },
      {
        path: 'levels/:levelId',
        loadComponent: () => import('./features/level/level.page').then(m => m.LevelPage),
        title: 'مستوى | مسار'
      },
      {
        path: 'learn/:levelId/:lessonSlug',
        loadComponent: () => import('./features/lesson/lesson.page').then(m => m.LessonPage),
        title: 'درس | مسار'
      },
      {
        path: 'quiz/:levelId',
        loadComponent: () => import('./features/quiz/quiz.page').then(m => m.QuizPage),
        title: 'اختبار | مسار'
      },
      {
        path: 'projects',
        loadComponent: () => import('./features/projects/projects.page').then(m => m.ProjectsPage),
        title: 'المشاريع | مسار'
      },
      {
        path: 'libraries',
        loadComponent: () => import('./features/libraries/libraries.page').then(m => m.LibrariesPage),
        title: 'المكتبات | مسار'
      },
      {
        path: 'ai',
        loadComponent: () => import('./features/ai/ai.page').then(m => m.AiPage),
        title: 'AI للمبرمجين | مسار'
      },
      {
        path: 'job-ready',
        loadComponent: () => import('./features/job/job.page').then(m => m.JobPage),
        title: 'جاهز للشغل | مسار'
      },
      {
        path: 'bookmarks',
        loadComponent: () => import('./features/bookmarks/bookmarks.page').then(m => m.BookmarksPage),
        title: 'المحفوظات | مسار'
      }
    ]
  },
  { path: '**', redirectTo: '' }
];
