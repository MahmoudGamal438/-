import { Component, computed, effect, inject, signal, untracked } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { map } from 'rxjs';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ContentBlock } from '../../core/models/curriculum.model';
import { CodeBlockComponent } from '../../shared/ui/code-block.component';
import { ArabicNumPipe } from '../../shared/pipes/arabic-num.pipe';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-lesson-page',
  imports: [RouterLink, FormsModule, CodeBlockComponent, ArabicNumPipe],
  templateUrl: './lesson.page.html'
})
export class LessonPage {
  private readonly route = inject(ActivatedRoute);
  private readonly curriculum = inject(CurriculumService);
  readonly progress = inject(ProgressService);
  private readonly sanitizer = inject(DomSanitizer);

  private readonly params = toSignal(
    this.route.paramMap.pipe(
      map(p => ({
        levelId: p.get('levelId') ?? '',
        slug: p.get('lessonSlug') ?? ''
      }))
    ),
    { initialValue: { levelId: '', slug: '' } }
  );

  readonly ctx = computed(() => {
    const { levelId, slug } = this.params();
    return this.curriculum.getLesson(levelId, slug);
  });

  readonly neighbors = computed(() => {
    const { levelId, slug } = this.params();
    return this.curriculum.neighbors(levelId, slug);
  });

  readonly showSolution = signal(false);

  constructor() {
    effect(() => {
      const found = this.ctx();
      if (!found) return;
      untracked(() => {
        this.progress.visitLesson(found.level.id, found.lesson.slug, found.lesson.title);
      });
    });
  }

  playgroundSrc(block: ContentBlock): SafeResourceUrl {
    const html = block.playground?.html ?? '';
    const css = block.playground?.css ?? '';
    const js = block.playground?.js ?? '';
    const doc = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{margin:12px}${css}</style></head><body>${html}<script>${js}<\/script></body></html>`;
    return this.sanitizer.bypassSecurityTrustResourceUrl(
      'data:text/html;charset=utf-8,' + encodeURIComponent(doc)
    );
  }

  complete(): void {
    const ctx = this.ctx();
    if (!ctx) return;
    this.progress.markLesson(ctx.lesson.id, ctx.level.id, ctx.lesson.slug, ctx.lesson.title);
  }
}
