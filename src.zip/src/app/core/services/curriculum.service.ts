import { Injectable } from '@angular/core';
import { AI_TOPICS } from '../../data/ai-topics';
import { LEVELS, PLATFORM } from '../../data/curriculum';
import { JOB_TOPICS } from '../../data/job-topics';
import { LIBRARIES } from '../../data/libraries';
import { Level, Lesson, Project } from '../models/curriculum.model';

@Injectable({ providedIn: 'root' })
export class CurriculumService {
  readonly platform = PLATFORM;
  readonly levels = LEVELS;
  readonly libraries = LIBRARIES;
  readonly aiTopics = AI_TOPICS;
  readonly jobTopics = JOB_TOPICS;

  getLevel(id: string): Level | undefined {
    return this.levels.find(level => level.id === id);
  }

  getLesson(levelId: string, slug: string): { level: Level; lesson: Lesson; index: number } | undefined {
    const level = this.getLevel(levelId);
    if (!level) return undefined;
    const index = level.lessons.findIndex(item => item.slug === slug);
    if (index < 0) return undefined;
    return { level, lesson: level.lessons[index], index };
  }

  neighbors(levelId: string, slug: string): { prev?: Lesson; next?: Lesson; nextLevel?: Level } {
    const found = this.getLesson(levelId, slug);
    if (!found) return {};
    const { level, index } = found;
    const prev = level.lessons[index - 1];
    const next = level.lessons[index + 1];
    const levelIndex = this.levels.findIndex(item => item.id === levelId);
    return {
      prev,
      next,
      nextLevel: next ? undefined : this.levels[levelIndex + 1]
    };
  }

  allLessons(): Array<{ level: Level; lesson: Lesson }> {
    return this.levels.flatMap(level => level.lessons.map(lesson => ({ level, lesson })));
  }

  allProjects(): Project[] {
    return this.levels.flatMap(level => level.projects);
  }

  search(term: string): Array<{ kind: 'lesson' | 'level' | 'project'; title: string; subtitle: string; link: string }> {
    const q = term.trim().toLowerCase();
    if (q.length < 2) return [];
    const hits: Array<{ kind: 'lesson' | 'level' | 'project'; title: string; subtitle: string; link: string }> = [];
    for (const level of this.levels) {
      if (`${level.title} ${level.titleEn} ${level.tagline}`.toLowerCase().includes(q)) {
        hits.push({
          kind: 'level',
          title: `${level.code} — ${level.title}`,
          subtitle: level.titleEn,
          link: `/levels/${level.id}`
        });
      }
      for (const lesson of level.lessons) {
        const hay = `${lesson.title} ${lesson.titleEn} ${lesson.summary}`.toLowerCase();
        if (hay.includes(q)) {
          hits.push({
            kind: 'lesson',
            title: lesson.title,
            subtitle: `${level.title} · ${lesson.titleEn}`,
            link: `/learn/${level.id}/${lesson.slug}`
          });
        }
      }
      for (const project of level.projects) {
        if (`${project.title} ${project.titleEn} ${project.summary}`.toLowerCase().includes(q)) {
          hits.push({
            kind: 'project',
            title: project.title,
            subtitle: project.titleEn,
            link: `/projects`
          });
        }
      }
    }
    return hits.slice(0, 12);
  }

  stats() {
    return {
      levels: this.levels.length,
      lessons: this.levels.reduce((sum, level) => sum + level.lessons.length, 0),
      projects: this.allProjects().length,
      quizzes: this.levels.reduce((sum, level) => sum + level.quiz.length, 0)
    };
  }
}
