export * from './curriculum.model';
