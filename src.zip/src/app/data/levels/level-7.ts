import { Level } from '../../core/models/curriculum.model';
import { compare, lesson, list, t, tip } from '../helpers';

export const LEVEL_7: Level = {
  id: 'ui-ecosystem',
  number: 7,
  code: 'L7',
  title: 'مكتبات الواجهة والنظام البيئي',
  titleEn: 'UI Libraries & Ecosystem',
  tagline: 'تختار العدة صح: مش كل مشروع محتاج نفس الصندوق.',
  color: '#8b5cf6',
  duration: '١٠–١٤ يوم',
  why: 'المطور المحترف بيعرف متى Bootstrap، متى Material، ومتى Tailwind، ومش بيحطهم فوق بعض عشوائي.',
  beforeYouStart: ['Angular fundamentals', 'CSS Grid/Flex مريح'],
  goals: [
    'تقارن مكتبات UI.',
    'تعرف Angular Material.',
    'تفهم Tailwind مع Angular.',
    'تختار Charts و Icons و Forms extras.',
    'توثق قرارك.'
  ],
  skillsGained: ['Angular Material', 'CDK', 'Tailwind awareness', 'Charts', 'Icon systems', 'Library selection'],
  nextSkills: ['مشاريع حجم شركة'],
  tools: ['Angular Material', 'Tailwind', 'NgRx أو Signals store حسب الحاجة', 'Chart libs'],
  lessons: [
    lesson(
      'l7-1',
      'how-to-choose',
      'ازاي تختار مكتبة',
      'Choosing Libraries',
      20,
      'السؤال مش "ايه الاشهر"، السؤال "ايه اللي هيعيش مع المشروع".',
      ['تحدد قيود المشروع.', 'تشوف الصيانة والمجتمع.', 'تحسب حجم الباقة.'],
      [
        list('اسئلة قبل npm install', [
          'عندنا ديزاين سيستم جاهز؟',
          'الفريق عارف CSS قد ايه؟',
          'محتاجين Accessibility جاهز؟',
          'حجم الـ bundle يهم؟',
          'الرخصة مناسبة؟'
        ]),
        tip('قاعدة', 'مكتبة واحدة للـ UI اساس. متخلطش Material و Bootstrap و Tailwind في نفس الصفحة من غير سبب.')
      ]
    ),
    lesson(
      'l7-2',
      'material-vs-tailwind',
      'Material و Bootstrap و Tailwind',
      'Material vs Tailwind vs Bootstrap',
      24,
      'ثلاث فلسفات.',
      ['تفهم الفروقات.', 'تعرف CDK.', 'تعرف Utility-first.'],
      [
        compare(
          'Angular Material',
          'مكونات جاهزة + Accessibility + CDK. ممتاز للوحات التحكم الداخلية.',
          'Tailwind CSS',
          'كلاسات صغيرة تبني بيها تصميمك. ممتاز لو عندك هوية بصرية خاصة.'
        ),
        t('Bootstrap سريع للـ MVP والنماذج الاولية. في Angular استخدم ng-bootstrap أو نسخ مدعومة، ومتكسرش الـ View Encapsulation عشوائي.')
      ]
    ),
    lesson(
      'l7-3',
      'charts-forms-state',
      'Charts و Forms extras و State',
      'Charts, Forms, State',
      22,
      'عدة المشروع الحقيقي.',
      ['تعرف متى Chart.', 'تعرف مكتبات Forms معقدة.', 'تعرف NgRx مش اجباري.'],
      [
        list('اختيارات شائعة', [
          'Icons: Angular Material Icons أو Lucide.',
          'Charts: Chart.js / ng2-charts أو ECharts.',
          'Rich forms: Angular Material form fields.',
          'State: Signals كافية غالبًا. NgRx للتعقيد العالي والفرق الكبيرة.'
        ]),
        t('متدخلش NgRx عشان السيرة الذاتية. دخّله لما الحالة تتشابك بين عشرات الشاشات واكشنز واضحة.')
      ]
    )
  ],
  quiz: [
    {
      id: 'l7-q1',
      prompt: 'Angular Material يتميز بـ ايه؟',
      options: ['انه اصغر bundle دائمًا', 'مكونات جاهزة و CDK ووصولية قوية', 'انه بديل TypeScript', 'انه قاعدة بيانات'],
      answerIndex: 1,
      explanation: 'Material منظومة مكونات، مش بس شكل.'
    }
  ],
  projects: [
    {
      id: 'l7-p1',
      title: 'لوحة إحصائيات كورس',
      titleEn: 'Course Analytics UI',
      size: 'mini',
      levelId: 'ui-ecosystem',
      duration: '٣ ايام',
      summary: 'داشبورد Material أو Tailwind فيه رسم تقدم ومكونات فلترة.',
      skills: ['UI kit', 'Charts', 'Theming'],
      features: ['Theme', 'Chart', 'Data table'],
      portfolioValue: 'يبين ذوقك في الواجهات الادارية.'
    }
  ]
};
