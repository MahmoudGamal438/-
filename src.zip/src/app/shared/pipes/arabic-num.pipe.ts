import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'arNum' })
export class ArabicNumPipe implements PipeTransform {
  transform(value: number | string | null | undefined): string {
    if (value === null || value === undefined) return '';
    const map = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return String(value).replace(/\d/g, d => map[Number(d)]);
  }
}
