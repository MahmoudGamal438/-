import { Component, inject } from '@angular/core';
import { CurriculumService } from '../../core/services/curriculum.service';

@Component({
  selector: 'app-libraries-page',
  template: `
    <section class="page-head">
      <div>
        <p class="eyebrow">Ecosystem</p>
        <h1>المكتبات: امتى، وليه، ومين ضد مين</h1>
        <p>المطور المحترف مش بيجمع npm زي الستيكرات. بيختار عدة تناسب المشروع.</p>
      </div>
    </section>
    <div class="lib-grid">
      @for (lib of curriculum.libraries; track lib.id) {
        <article class="lib-card">
          <span class="pill">{{ lib.category }}</span>
          <h2>{{ lib.name }}</h2>
          <h3>امتى؟</h3>
          <p>{{ lib.when }}</p>
          <h3>مقابل إيه؟</h3>
          <p>{{ lib.vs }}</p>
          <h3>ازاي؟</h3>
          <p>{{ lib.how }}</p>
        </article>
      }
    </div>
  `
})
export class LibrariesPage {
  readonly curriculum = inject(CurriculumService);
}
