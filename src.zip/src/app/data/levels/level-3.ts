import { Level } from '../../core/models/curriculum.model';
import { analogy, code, lesson, list, play, t, tip, warn } from '../helpers';

export const LEVEL_3: Level = {
  id: 'javascript',
  number: 3,
  code: 'L3',
  title: 'JavaScript',
  titleEn: 'JavaScript',
  tagline: 'تخلي الصفحة تفكر وتتفاعل، بالقدر اللي Angular محتاجه.',
  color: '#eab308',
  duration: '٢١–٣٠ يوم',
  why: 'Angular طبقة فوق JavaScript. من غير JS، هتحفظ ديكوريشن من غير فهم.',
  beforeYouStart: ['HTML و CSS مريحين', 'فاهم Functions و Arrays', 'DevTools Console جاهز'],
  goals: [
    'تسيطر على DOM و Events.',
    'تفهم ES6+ اللي هتشوفه يوميًا.',
    'تتعامل مع Async و Fetch.',
    'تعرف Modules.',
    'تمسك Errors بدل ما تكسر الصفحة.'
  ],
  skillsGained: ['ES6+', 'DOM', 'Events', 'Promises', 'Async/Await', 'Fetch', 'Modules', 'OOP basics'],
  nextSkills: ['TypeScript types', 'Interfaces'],
  tools: ['Chrome Console', 'VS Code', 'JSONPlaceholder أو أي API تجريبي'],
  lessons: [
    lesson(
      'l3-1',
      'js-in-the-browser',
      'JavaScript في المتصفح',
      'JS in the Browser',
      22,
      'المتصفح بيحمّل HTML بعدين يشغّل JS عشان الحياة تبدأ.',
      ['تربط سكربت بالصفحة.', 'تعرف الفرق بين defer و الوضع الغلط.', 'تستخدم console كمعمل.'],
      [
        t('JavaScript لغة البرمجة بتاعة الويب. Angular في الاخر بيتحول لـ JS يشتغل في المتصفح. لو فهمت اللغة، الفريمورك هيبقى ادوات مش طلاسم.'),
        code('html', `<script type="module" src="./main.js"></script>`),
        tip('اتعلم في Console', 'افتح أي صفحة، F12، اكتب 2+2. المعمل قدامك.')
      ]
    ),
    lesson(
      'l3-2',
      'es6-plus',
      'ES6+: اللغة الحديثة',
      'ES6+',
      28,
      'arrow functions, destructuring, spread, template strings, optional chaining.',
      ['تكتب كود حديث مقروء.', 'تفكك Object بأمان.', 'تستخدم map/filter/reduce بوعي.'],
      [
        code(
          'javascript',
          `const lesson = { id: 3, title: 'ES6', minutes: 28 };\nconst { title, minutes } = lesson;\nconst line = \`الدرس \${title} — \${minutes} دقيقة\`;\nconst done = [1, 2, 3].map(n => n * 10);\nconst next = { ...lesson, done: true };\nconsole.log(line, done, next.title, lesson?.author?.name);`
        ),
        list('اللي هتستخدمه في Angular كل يوم', [
          'const / let',
          'Arrow functions',
          'Destructuring',
          'Spread',
          'Promises / async',
          'Modules'
        ])
      ]
    ),
    lesson(
      'l3-3',
      'dom-events',
      'DOM و Events',
      'DOM and Events',
      26,
      'ازاي الصفحة شجرة، وازاي الزرار بيسمع.',
      ['تختار عنصر.', 'تسمع لحدث.', 'تحدث النص من غير ما تعيد تحميل الصفحة.'],
      [
        analogy('شجرة', 'الـ DOM شجرة العيلة بتاعة الصفحة. html اب، body ابن، الزرار حفيد. JS تقدر تمشي على الشجرة وتغيّر.'),
        play(
          `<button id="btn">اضغط</button><p id="out">لسه</p>`,
          `body{font-family:sans-serif}#btn{padding:8px 14px;border:0;border-radius:8px;background:#0d9488;color:#fff}`,
          `const btn = document.getElementById('btn');\nconst out = document.getElementById('out');\nbtn.addEventListener('click', () => {\n  out.textContent = 'تمام، الحدث وصل';\n});`
        ),
        warn('Angular والـ DOM', 'في Angular نادرًا هتمسك document.getElementById. بس لازم تفهم الآلية عشان الـ Binding ميبقاش سحر.')
      ]
    ),
    lesson(
      'l3-4',
      'async-js',
      'Async: العالم مش متزامن',
      'Async JavaScript',
      28,
      'Promises و async/await من غير صداع.',
      ['تفهم ليه الانتظار ضروري.', 'تكتب async function.', 'تمسك الخطأ بـ try/catch.'],
      [
        t('لما تجيب بيانات من API، الشبكة بتاخد وقت. لو وقفت الصفحة تستنى، المستخدم يحس ان التطبيق مات. Async يعني: ابدأ الطلب، كمّل حياتك، لما الرد ييجي كمل.'),
        code(
          'javascript',
          `async function loadLessons() {\n  try {\n    const res = await fetch('/api/lessons');\n    if (!res.ok) throw new Error('الشبكة مش موافقة');\n    const data = await res.json();\n    return data;\n  } catch (err) {\n    console.error(err);\n    return [];\n  }\n}`
        )
      ]
    ),
    lesson(
      'l3-5',
      'fetch-apis',
      'APIs و Fetch',
      'APIs and Fetch',
      24,
      'التطبيق الحقيقي بيعيش على بيانات برة الصفحة.',
      ['تبني طلب GET.', 'تفهم JSON.', 'تعرف Status codes الشائعة.'],
      [
        list('رموز تشوفها', ['200 تمام', '201 اتعمل', '400 غلط منك', '401 محتاج تسجل', '404 مش موجود', '500 الغلط عند السيرفر']),
        code(
          'javascript',
          `const res = await fetch('https://jsonplaceholder.typicode.com/posts/1');\nconst post = await res.json();\nconsole.log(post.title);`
        )
      ]
    ),
    lesson(
      'l3-6',
      'modules-errors-oop',
      'Modules و Error Handling و OOP',
      'Modules, Errors, OOP',
      26,
      'تقسيم الملفات والكائنات.',
      ['تعمل export/import.', 'ترمي Error مفهوم.', 'تفهم class بشكل عملي.'],
      [
        code(
          'javascript',
          `export function percent(done, total) {\n  if (total <= 0) throw new Error('total لازم اكبر من صفر');\n  return Math.round((done / total) * 100);\n}`
        ),
        t('OOP مش لازم تتفلسف فيه. في Angular الـ Class هو شكل الـ Component والـ Service. فاهم: خصائص + دوال + حقن اعتماديات.')
      ],
      {
        exercise: {
          id: 'l3-ex',
          title: 'قائمة دروس من API',
          difficulty: 'medium',
          brief: 'اجلب بيانات و اعرض العناوين في الصفحة. لو فشل الطلب اظهر رسالة.',
          hints: ['async/await', 'try/catch', 'createElement او innerText'],
          solution: 'fetch ثم json ثم loop على العناصر مع معالجة !res.ok.'
        },
        challenge: {
          id: 'l3-ch',
          title: 'باحث مهام',
          brief: 'ابحث في قائمة مهام محلية بالاسم، مع تأخير وهمي يحاكي API.',
          goals: ['filter', 'Promise', 'DOM update']
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l3-q1',
      prompt: 'await بتستخدم جوه ايه؟',
      options: ['أي دالة عادية', 'دالة معلمة async', 'ملف CSS', 'HTML comment'],
      answerIndex: 1,
      explanation: 'await جوه async function، وبتستنى الـ Promise يتحل.'
    },
    {
      id: 'l3-q2',
      prompt: 'map على Array بتعمل ايه؟',
      options: ['تمسح العناصر', 'ترجع مصفوفة جديدة بعد تحويل كل عنصر', 'تفرز الملفات', 'تفتح المتصفح'],
      answerIndex: 1,
      explanation: 'map تحويل بدون ما تشوه المصفوفة الاصلية لو كتبتها صح.'
    },
    {
      id: 'l3-q3',
      prompt: 'JSON تقريبًا ايه؟',
      options: ['لغة تصميم', 'صيغة بيانات نصية للكائنات والقوائم', 'قاعدة بيانات', 'فريمورك'],
      answerIndex: 1,
      explanation: 'JSON طريقة نقل البيانات بين السيرفر والعميل.'
    }
  ],
  projects: [
    {
      id: 'l3-p1',
      title: 'متتبع تعلم في المتصفح',
      titleEn: 'Browser Learning Tracker',
      size: 'medium',
      levelId: 'javascript',
      duration: '٣ ايام',
      summary: 'صفحة بتضيف دروس، تعلمها مكتملة، وتحسب النسبة. البيانات في localStorage.',
      skills: ['DOM', 'Events', 'localStorage', 'Modules'],
      features: ['CRUD بسيط', 'فلترة', 'نسبة تقدم'],
      portfolioValue: 'مشروع صغير يوضح انك فاهم JS قبل الفريمورك.'
    }
  ]
};
