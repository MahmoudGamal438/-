import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurriculumService } from '../../core/services/curriculum.service';

@Component({
  selector: 'app-job-page',
  imports: [RouterLink],
  template: `
    <section class="page-head">
      <div>
        <p class="eyebrow">From learner to hireable</p>
        <h1>من متعلم لـ Angular Developer جاهز للشغل</h1>
        <p>Angular مش آخر المحطة. بعدها فريق، نشر، سيرة، مقابلة، وتاسك بساعة رمل.</p>
      </div>
    </section>
    <div class="topic-stack">
      @for (topic of curriculum.jobTopics; track topic.id) {
        <article class="topic">
          <h2>{{ topic.title }}</h2>
          <p>{{ topic.summary }}</p>
          @for (block of topic.blocks; track $index) {
            @if (block.type === 'text') {
              <p class="prose">{{ block.body }}</p>
            }
            @if (block.type === 'list') {
              <ul class="check">
                @for (item of block.items; track item) {
                  <li>{{ item }}</li>
                }
              </ul>
            }
          }
        </article>
      }
    </div>
    <section class="band">
      <h2>بعد إتقان Angular اتعلم</h2>
      <div class="chips">
        @for (item of curriculum.platform.afterAngular; track item) {
          <span>{{ item }}</span>
        }
      </div>
      <a class="btn primary" routerLink="/levels/job-ready">دخول مستوى التأهيل</a>
    </section>
  `
})
export class JobPage {
  readonly curriculum = inject(CurriculumService);
}
