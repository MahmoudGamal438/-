import { Injectable, computed, inject, signal } from '@angular/core';
import { CurriculumService } from './curriculum.service';
import { StorageService } from './storage.service';

interface ProgressState {
  completedLessons: string[];
  quizScores: Record<string, number>;
  bookmarks: string[];
  notes: Record<string, string>;
  lastLesson?: { levelId: string; slug: string; title: string };
}

const KEY = 'masar.progress.v1';

const EMPTY: ProgressState = {
  completedLessons: [],
  quizScores: {},
  bookmarks: [],
  notes: {}
};

@Injectable({ providedIn: 'root' })
export class ProgressService {
  private readonly storage = inject(StorageService);
  private readonly curriculum = inject(CurriculumService);
  private readonly state = signal<ProgressState>(this.storage.read(KEY, EMPTY));

  readonly completed = computed(() => new Set(this.state().completedLessons));
  readonly bookmarks = computed(() => this.state().bookmarks);
  readonly lastLesson = computed(() => this.state().lastLesson);
  readonly notes = computed(() => this.state().notes);
  readonly quizScores = computed(() => this.state().quizScores);

  readonly overallPercent = computed(() => {
    const total = this.curriculum.stats().lessons;
    if (!total) return 0;
    return Math.round((this.state().completedLessons.length / total) * 100);
  });

  isLessonDone(id: string): boolean {
    return this.completed().has(id);
  }

  levelPercent(levelId: string): number {
    const level = this.curriculum.getLevel(levelId);
    if (!level || level.lessons.length === 0) return 0;
    const done = level.lessons.filter(lesson => this.completed().has(lesson.id)).length;
    return Math.round((done / level.lessons.length) * 100);
  }

  isLevelUnlocked(levelId: string): boolean {
    const levels = this.curriculum.levels;
    const index = levels.findIndex(level => level.id === levelId);
    if (index <= 0) return true;
    const prev = levels[index - 1];
    const lessonsDone = prev.lessons.every(lesson => this.completed().has(lesson.id));
    const quizOk = !prev.quiz.length || (this.state().quizScores[prev.id] ?? 0) >= 70;
    return lessonsDone && quizOk;
  }

  currentLevel() {
    return this.curriculum.levels.find(level => this.levelPercent(level.id) < 100) ?? this.curriculum.levels.at(-1);
  }

  toggleLesson(id: string): void {
    this.patch(state => {
      const set = new Set(state.completedLessons);
      if (set.has(id)) set.delete(id);
      else set.add(id);
      return { ...state, completedLessons: [...set] };
    });
  }

  markLesson(id: string, levelId: string, slug: string, title: string): void {
    this.patch(state => ({
      ...state,
      completedLessons: state.completedLessons.includes(id)
        ? state.completedLessons
        : [...state.completedLessons, id],
      lastLesson: { levelId, slug, title }
    }));
  }

  visitLesson(levelId: string, slug: string, title: string): void {
    this.patch(state => ({ ...state, lastLesson: { levelId, slug, title } }));
  }

  saveQuiz(levelId: string, score: number): void {
    this.patch(state => ({
      ...state,
      quizScores: { ...state.quizScores, [levelId]: score }
    }));
  }

  toggleBookmark(lessonId: string): void {
    this.patch(state => {
      const exists = state.bookmarks.includes(lessonId);
      return {
        ...state,
        bookmarks: exists
          ? state.bookmarks.filter(id => id !== lessonId)
          : [...state.bookmarks, lessonId]
      };
    });
  }

  isBookmarked(lessonId: string): boolean {
    return this.state().bookmarks.includes(lessonId);
  }

  saveNote(lessonId: string, note: string): void {
    this.patch(state => ({
      ...state,
      notes: { ...state.notes, [lessonId]: note }
    }));
  }

  reset(): void {
    this.state.set(EMPTY);
    this.storage.write(KEY, EMPTY);
  }

  private patch(mutator: (state: ProgressState) => ProgressState): void {
    const next = mutator(this.state());
    this.state.set(next);
    this.storage.write(KEY, next);
  }
}
