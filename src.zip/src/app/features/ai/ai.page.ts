import { Component, inject } from '@angular/core';
import { CurriculumService } from '../../core/services/curriculum.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-ai-page',
  imports: [RouterLink],
  template: `
    <section class="page-head">
      <div>
        <p class="eyebrow">AI for developers</p>
        <h1>الذكاء الاصطناعي زميلك، مش بديل دماغك</h1>
        <p>القسم ده بيتحدث مع الأدوات، بس المبدأ ثابت: فهم → تجربة → مساعدة → مراجعة.</p>
      </div>
    </section>
    <div class="topic-stack">
      @for (topic of curriculum.aiTopics; track topic.id) {
        <article class="topic">
          <h2>{{ topic.title }}</h2>
          <p>{{ topic.summary }}</p>
          @for (block of topic.blocks; track $index) {
            @if (block.type === 'text') {
              <p class="prose">{{ block.body }}</p>
            }
            @if (block.type === 'list') {
              <ul class="check">
                @for (item of block.items; track item) {
                  <li>{{ item }}</li>
                }
              </ul>
            }
            @if (block.type === 'tip' || block.type === 'warning') {
              <aside class="callout" [class.tip]="block.type === 'tip'" [class.warn]="block.type === 'warning'">
                <strong>{{ block.title }}</strong>
                <p>{{ block.body }}</p>
              </aside>
            }
          }
        </article>
      }
    </div>
    <p><a routerLink="/levels/ai-for-developers">افتح مستوى AI كامل داخل الخريطة</a></p>
  `
})
export class AiPage {
  readonly curriculum = inject(CurriculumService);
}
