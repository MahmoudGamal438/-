import { ContentBlock, Lesson } from '../core/models/curriculum.model';

export function t(body: string): ContentBlock {
  return { type: 'text', body };
}

export function h(title: string): ContentBlock {
  return { type: 'heading', title };
}

export function tip(title: string, body: string): ContentBlock {
  return { type: 'tip', title, body };
}

export function warn(title: string, body: string): ContentBlock {
  return { type: 'warning', title, body };
}

export function analogy(title: string, body: string): ContentBlock {
  return { type: 'analogy', title, body };
}

export function list(title: string, items: string[]): ContentBlock {
  return { type: 'list', title, items };
}

export function steps(title: string, items: string[]): ContentBlock {
  return { type: 'steps', title, items };
}

export function code(
  language: NonNullable<ContentBlock['language']>,
  code: string,
  title?: string
): ContentBlock {
  return { type: 'code', language, code, title };
}

export function play(html: string, css = '', js = ''): ContentBlock {
  return { type: 'playground', playground: { html, css, js } };
}

export function compare(leftTitle: string, left: string, rightTitle: string, right: string): ContentBlock {
  return { type: 'compare', leftTitle, left, rightTitle, right };
}

export function lesson(
  id: string,
  slug: string,
  title: string,
  titleEn: string,
  durationMin: number,
  summary: string,
  objectives: string[],
  blocks: ContentBlock[],
  extra?: Partial<Lesson>
): Lesson {
  return { id, slug, title, titleEn, durationMin, summary, objectives, blocks, ...extra };
}
