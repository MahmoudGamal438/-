import { Level } from '../../core/models/curriculum.model';
import { analogy, code, h, lesson, list, play, steps, t, tip, warn } from '../helpers';

export const LEVEL_2: Level = {
  id: 'html-css',
  number: 2,
  code: 'L2',
  title: 'HTML و CSS',
  titleEn: 'HTML & CSS',
  tagline: 'تبني صفحات حقيقية: هيكل واضح وشكل احترافي.',
  color: '#f97316',
  duration: '١٨–٢٤ يوم',
  why: 'Angular بيرسم واجهات. لو HTML و CSS ضعاف، هتكتب Components تخين ومش متجاوبة.',
  beforeYouStart: ['فاهم Variables و Conditions', 'تعرف تستخدم VS Code', 'المتصفح DevTools مفتوح'],
  goals: [
    'تبني صفحة Semantic.',
    'تستخدم Flexbox و Grid بثقة.',
    'تعمل تصميم Responsive.',
    'تفهم Accessibility مبكرًا.',
    'تنظم ملفات التنسيق.'
  ],
  skillsGained: ['Semantic HTML', 'Forms', 'Flexbox', 'CSS Grid', 'Responsive', 'Animations basics'],
  nextSkills: ['JavaScript في المتصفح', 'DOM'],
  tools: ['VS Code', 'Chrome DevTools', 'أي Browser حديث'],
  lessons: [
    lesson(
      'l2-1',
      'html-from-zero',
      'HTML من الصفر: الهيكل مش الديكور',
      'HTML Fundamentals',
      28,
      'HTML لغة توصيف، مش لغة برمجة. هي الهيكل العظمي.',
      ['تعرف الفرق بين Tag و Element.', 'تبني صفحة فيها header و main و footer.', 'تفهم ان المعنى اهم من الشكل.'],
      [
        t('HTML بتخلي المتصفح يفهم: ده عنوان، ده زرار، ده رابط، ده نموذج. CSS بعد كده بيقول الشكل. لو بنيت كل حاجة بـ div، الصفحة شكلها ممكن يبقى حلو، بس محركات البحث وقارئ الشاشة هيتلخبطوا.'),
        code(
          'html',
          `<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n  <head>\n    <meta charset="UTF-8" />\n    <title>مسار</title>\n  </head>\n  <body>\n    <header>\n      <h1>مسار Angular</h1>\n      <nav><a href="#lessons">الدروس</a></nav>\n    </header>\n    <main>\n      <article>\n        <h2>اول درس</h2>\n        <p>الهيكل الواضح بيسهّل الصيانة.</p>\n      </article>\n    </main>\n    <footer>صنع بحب للتعلم</footer>\n  </body>\n</html>`
        ),
        play(
          `<header class="box">مسار</header>\n<main class="box">المحتوى هنا</main>\n<footer class="box">footer</footer>`,
          `.box{padding:12px;margin:8px 0;border-radius:12px;background:#0f172a;color:#e2e8f0;font-family:sans-serif}`
        )
      ]
    ),
    lesson(
      'l2-2',
      'semantic-and-a11y',
      'Semantic HTML و Accessibility',
      'Semantic HTML & Accessibility',
      22,
      'الصفحة تتفهم للبشر والآلات.',
      ['تستخدم button مش div كزرار.', 'تربط label بالـ input.', 'تعرف معنى alt.'],
      [
        list('بدائل اذكى من div', [
          'nav للقائمة.',
          'button للحركة.',
          'article للمحتوى المستقل.',
          'label + input للنماذج.'
        ]),
        warn('div onclick', 'لو عملت ديڤ كليك، الكيبورد وقارئ الشاشة مش هيعرفوا ان ده زرار. استخدم button.'),
        tip('alt مش وصف شعري', 'اكتب اللي الصورة بتعمله في السياق. لو ديكور، alt فاضي.')
      ]
    ),
    lesson(
      'l2-3',
      'forms',
      'Forms: باب الدخول لأي تطبيق',
      'HTML Forms',
      24,
      'المدخلات هي نص التطبيق.',
      ['تبني فورم تسجيل.', 'تعرف required و type.', 'تفهم ان الفاليديشن في HTML بداية مش نهاية.'],
      [
        code(
          'html',
          `<form>\n  <label for="email">الايميل</label>\n  <input id="email" type="email" required />\n  <label for="password">كلمة السر</label>\n  <input id="password" type="password" minlength="8" required />\n  <button type="submit">دخول</button>\n</form>`
        ),
        t('في Angular هتستخدم Reactive Forms، بس الاساس واحد: اسم الحقل، نوعه، وهل اجباري، وايه رسالة الغلط.')
      ]
    ),
    lesson(
      'l2-4',
      'css-box-model',
      'CSS Selectors و Box Model',
      'Selectors & Box Model',
      26,
      'كل عنصر صندوق. فهم الصندوق = فهم التصميم.',
      ['تختار عنصر بدقة.', 'تفرق margin و padding و border.', 'تستخدم box-sizing: border-box.'],
      [
        analogy(
          'صندوق شحن',
          'المحتوى هو المنتج. Padding الهواء جوه الكرتونة. Border جدار الكرتونة. Margin المسافة بين الكراتين على الرف.'
        ),
        code(
          'css',
          `* { box-sizing: border-box; }\n.card {\n  width: 320px;\n  padding: 16px;\n  border: 1px solid #334155;\n  margin-bottom: 12px;\n}`
        )
      ]
    ),
    lesson(
      'l2-5',
      'flexbox',
      'Flexbox: صفّ العناصر بعقلك',
      'Flexbox',
      26,
      'Navbar، صفوف كروت، محاذاة عمودية.',
      ['تعمل صف توزيع.', 'تستخدم gap.', 'توسط عنصر عموديًا.'],
      [
        code(
          'css',
          `.row {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}`
        ),
        play(
          `<div class="nav"><strong>مسار</strong><div class="links"><span>الخريطة</span><span>الدروس</span></div></div>`,
          `.nav{display:flex;justify-content:space-between;align-items:center;background:#111827;color:#fff;padding:12px 16px;border-radius:12px;font-family:sans-serif}.links{display:flex;gap:12px;opacity:.85}`
        )
      ]
    ),
    lesson(
      'l2-6',
      'css-grid',
      'CSS Grid: تخطيط الصفحات',
      'CSS Grid',
      24,
      'Grid للمساحات الكبيرة، Flex للتفاصيل.',
      ['تقسم صفحة لـ sidebar و main.', 'تعمل بطاقات متساوية.', 'تستخدم repeat و minmax.'],
      [
        code(
          'css',
          `.layout {\n  display: grid;\n  grid-template-columns: 260px 1fr;\n  min-height: 100vh;\n}\n.cards {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));\n  gap: 16px;\n}`
        ),
        tip('قاعدة عملية', 'Grid للهيكل. Flex للمحتوى جوه الكرت. متتحولش كل حاجة Grid.')
      ]
    ),
    lesson(
      'l2-7',
      'responsive',
      'Responsive و Media Queries',
      'Responsive Design',
      24,
      'التصميم يبدأ من الموبايل ويتوسع.',
      ['تخلي الصفحة تتشاف على موبايل.', 'تستخدم clamp للخطوط.', 'تعرف breakpoints معقولة.'],
      [
        code(
          'css',
          `:root { --space: clamp(12px, 2vw, 24px); }\n.hero h1 { font-size: clamp(1.6rem, 4vw, 3rem); }\n@media (max-width: 800px) {\n  .layout { grid-template-columns: 1fr; }\n}`
        ),
        t('في Angular هتستخدم نفس الـ CSS. الـ Component مش هينقذك من Layout وحش.')
      ]
    ),
    lesson(
      'l2-8',
      'css-architecture',
      'تنظيم CSS و Animations',
      'CSS Architecture',
      20,
      'ملفات واضحة، متغيرات، حركة خفيفة.',
      ['تعمل CSS variables.', 'تفصل ملف layout عن ملف components.', 'تضيف hover بسيط من غير مبالغة.'],
      [
        code(
          'css',
          `:root {\n  --bg: #0b1220;\n  --card: #121a2b;\n  --accent: #14b8a6;\n}\n.button {\n  transition: transform .15s ease, background .15s ease;\n}\n.button:hover { transform: translateY(-1px); }`
        ),
        steps('مشروع الدرس', [
          'صفحة هبوط لمسار تعليمي.',
          'Navbar + Hero + 3 كروت مستويات + Footer.',
          'تشتغل من 360px لـ 1200px.'
        ])
      ],
      {
        exercise: {
          id: 'l2-ex',
          title: 'كرت درس',
          difficulty: 'medium',
          brief: 'ابنِ كرت فيه عنوان الدرس، مدة، وزرار ابدأ. استخدم Flex جوه الكرت.',
          hints: ['border-radius و padding.', 'زرار حقيقي button.'],
          solution: 'بطاقة semantic فيها h3 و p و button، مع display:flex; flex-direction:column; gap:8px;'
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l2-q1',
      prompt: 'ليه نستخدم button بدل div للضغط؟',
      options: ['الشكل احلى', 'الوصولية والكيبورد والدلالة الصحيحة', 'جوجل بتطلب كده بس', 'Angular مش بيفهم div'],
      answerIndex: 1,
      explanation: 'الزرار عنصر تفاعلي جاهز للكيبورد وقارئ الشاشة.'
    },
    {
      id: 'l2-q2',
      prompt: 'Box Model ترتيب الطبقات من جوه لبرا؟',
      options: ['margin ثم content', 'content ثم padding ثم border ثم margin', 'border ثم content', 'padding بس'],
      answerIndex: 1,
      explanation: 'المحتوى جوه، بعده padding، border، وأخيرًا margin.'
    },
    {
      id: 'l2-q3',
      prompt: 'Flexbox انسب امتى؟',
      options: ['خرائط جغرافية', 'صفوف ومحاذاة عناصر', 'قواعد بيانات', 'فيديوهات'],
      answerIndex: 1,
      explanation: 'Flex ممتاز للمحاور والمحاذاة داخل مكوّن.'
    }
  ],
  projects: [
    {
      id: 'l2-p1',
      title: 'صفحة هبوط مسار',
      titleEn: 'Masar Landing',
      size: 'mini',
      levelId: 'html-css',
      duration: 'يوم',
      summary: 'صفحة تعريف بالمسار: بطل، مستويات، رأي طالب، CTA.',
      skills: ['Semantic HTML', 'Flex', 'Responsive'],
      features: ['Hero', 'Cards', 'Footer', 'Mobile first'],
      portfolioValue: 'اول حاجة تتحط في GitHub لو متصممة بعناية.'
    },
    {
      id: 'l2-p2',
      title: 'لوحة درس',
      titleEn: 'Lesson Dashboard UI',
      size: 'medium',
      levelId: 'html-css',
      duration: 'يومين',
      summary: 'واجهة فيها سايدبار دروس ومحتوى وشريط تقدم. من غير JS تقريبًا.',
      skills: ['Grid', 'CSS variables', 'Accessibility'],
      features: ['Sidebar', 'Progress bar', 'Card list'],
      portfolioValue: 'شكل قريب من المنصات التعليمية الحقيقية.'
    }
  ]
};
