import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ArabicNumPipe } from '../../shared/pipes/arabic-num.pipe';

@Component({
  selector: 'app-quiz-page',
  imports: [RouterLink, ArabicNumPipe],
  templateUrl: './quiz.page.html'
})
export class QuizPage {
  private readonly route = inject(ActivatedRoute);
  private readonly curriculum = inject(CurriculumService);
  readonly progress = inject(ProgressService);
  private readonly levelId = toSignal(this.route.paramMap.pipe(map(p => p.get('levelId') ?? '')), {
    initialValue: ''
  });
  readonly level = computed(() => this.curriculum.getLevel(this.levelId()));
  readonly answers = signal<Record<string, number>>({});
  readonly submitted = signal(false);

  score(): number {
    const level = this.level();
    if (!level || !level.quiz.length) return 0;
    let ok = 0;
    for (const q of level.quiz) {
      if (this.answers()[q.id] === q.answerIndex) ok++;
    }
    return Math.round((ok / level.quiz.length) * 100);
  }

  choose(id: string, index: number): void {
    if (this.submitted()) return;
    this.answers.update(curr => ({ ...curr, [id]: index }));
  }

  submit(): void {
    const level = this.level();
    if (!level) return;
    this.submitted.set(true);
    this.progress.saveQuiz(level.id, this.score());
  }
}
