import { Level } from '../../core/models/curriculum.model';
import { analogy, code, lesson, list, t, tip, warn } from '../helpers';

export const LEVEL_4: Level = {
  id: 'typescript',
  number: 4,
  code: 'L4',
  title: 'TypeScript',
  titleEn: 'TypeScript',
  tagline: 'نفس JavaScript، بس بجواز سفر للأنواع عشان Angular يساعدك بدري.',
  color: '#38bdf8',
  duration: '١٠–١٤ يوم',
  why: 'Angular TypeScript-first. الأنواع مش بيروقراطية، هي نظام إنذار مبكر.',
  beforeYouStart: ['JS مريح في Functions و Arrays و Async', 'تعرف Modules'],
  goals: [
    'تكتب types واضحة.',
    'تستخدم interface و type.',
    'تفهم Generics بشكل عملي.',
    'تقرا اخطاء الـ compiler.',
    'تعرف متى any حرام.'
  ],
  skillsGained: ['Types', 'Interfaces', 'Unions', 'Generics', 'Utility types', 'Strict mode'],
  nextSkills: ['Angular components', 'Templates'],
  tools: ['TypeScript Playground', 'VS Code', 'Angular Language Service لاحقًا'],
  lessons: [
    lesson(
      'l4-1',
      'why-ts',
      'ليه TypeScript قبل Angular',
      'Why TypeScript',
      18,
      'الغلط يتشاف وانت بتكتب، مش بعد ما المستخدم يدوس.',
      ['تعرف TS طبقة فوق JS.', 'تفهم ان المتصفح لسه بيشغل JS.', 'تحترم strict.'],
      [
        analogy(
          'تذاكر القطر',
          'JavaScript بتدخل القطر من غير تذكرة واضحة. TypeScript بتوقفك عند الباب: المكان ده للكبار بس، العدد ده مش نص. Angular عايش في المحطة دي.'
        ),
        code(
          'typescript',
          `let score: number = 80;\n// score = 'ثمانين'; // Error من بدري\nfunction label(done: number, total: number): string {\n  return \`\${done}/\${total}\`;\n}`
        )
      ]
    ),
    lesson(
      'l4-2',
      'types-interfaces',
      'Types و Interfaces',
      'Types and Interfaces',
      24,
      'وصف شكل البيانات قبل ما تبني الشاشات.',
      ['تكتب interface لدرس.', 'تستخدم optional و readonly.', 'تعرف Union.'],
      [
        code(
          'typescript',
          `interface Lesson {\n  id: string;\n  title: string;\n  durationMin: number;\n  done?: boolean;\n}\n\ntype Difficulty = 'easy' | 'medium' | 'hard';\n\nconst cssBox: Lesson = {\n  id: 'l2-4',\n  title: 'Box Model',\n  durationMin: 26\n};`
        ),
        tip('Interface للعقود', 'لو هتشارك شكل بيانات بين Component و Service، interface اوضح.')
      ]
    ),
    lesson(
      'l4-3',
      'generics-utils',
      'Generics و Utility Types',
      'Generics',
      26,
      'دالة واحدة تشتغل على اكثر من نوع بأمان.',
      ['تفهم ApiResponse<T>.', 'تستخدم Partial و Pick.', 'تبطل any.'],
      [
        code(
          'typescript',
          `interface ApiResponse<T> {\n  data: T;\n  ok: boolean;\n}\n\nfunction wrap<T>(data: T): ApiResponse<T> {\n  return { data, ok: true };\n}\n\nconst lessons = wrap<Lesson[]>([]);\ntype LessonPreview = Pick<Lesson, 'id' | 'title'>;`
        ),
        warn('any باب خلفي', 'any بيطفي المنبه. لو مش عارف النوع، unknown + narrowing احسن.')
      ]
    ),
    lesson(
      'l4-4',
      'ts-for-angular',
      'TypeScript اللي Angular هيسألك عنه',
      'TS for Angular',
      22,
      'Input types، نماذج، وخدمات.',
      ['تكتب نوع لـ Form.', 'تعرف visiblity public/private.', 'تقرا خطأ TS2678 بهدوء.'],
      [
        list('هتشوفهم في المشروع', [
          'typed forms',
          'inject(Service)',
          'signal<Lesson[]>()',
          'HttpClient.get<Lesson[]>()'
        ]),
        code(
          'typescript',
          `class ProgressService {\n  private readonly total = 10;\n  percent(done: number): number {\n    return Math.round((done / this.total) * 100);\n  }\n}`
        )
      ],
      {
        exercise: {
          id: 'l4-ex',
          title: 'موديل منهج',
          difficulty: 'medium',
          brief: 'اكتب interfaces لـ Lesson و Level و QuizQuestion، ودالة ترجع عدد الدروس في مستوى.',
          hints: ['arrays داخل interface.', 'خلي الدالة ترجع number.'],
          solution: 'interface Level { lessons: Lesson[] } ثم level.lessons.length'
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l4-q1',
      prompt: 'Union type يعني ايه؟',
      options: ['دمج ملفات CSS', 'القيمة ممكن تكون واحد من انواع محددة', 'قاعدة بيانات', 'مشكلة Git'],
      answerIndex: 1,
      explanation: `'easy' | 'medium' | 'hard' مثال شائع.`
    },
    {
      id: 'l4-q2',
      prompt: 'ليه نتجنب any؟',
      options: ['عشان الكود يبقى اطول', 'لانه يلغي فائدة التحقق من الانواع', 'Angular مش بيدعمه', 'بيبطئ النت'],
      answerIndex: 1,
      explanation: 'any يرجعك لـ JS من غير شبكة امان.'
    }
  ],
  projects: [
    {
      id: 'l4-p1',
      title: 'محرك تقدم Typed',
      titleEn: 'Typed Progress Engine',
      size: 'mini',
      levelId: 'typescript',
      duration: 'يوم',
      summary: 'موديلات للمنهج ودوال حساب التقدم والمهارات المكتسبة بأنواع صارمة.',
      skills: ['Interfaces', 'Generics', 'Pure functions'],
      features: ['percent()', 'isUnlocked()', 'nextLesson()'],
      portfolioValue: 'يوضح نضجك قبل Angular.'
    }
  ]
};
