import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurriculumService } from '../../core/services/curriculum.service';
import { ProgressService } from '../../core/services/progress.service';
import { ArabicNumPipe } from '../../shared/pipes/arabic-num.pipe';
import { ProgressRingComponent } from '../../shared/ui/progress-ring.component';

@Component({
  selector: 'app-roadmap-page',
  imports: [RouterLink, ArabicNumPipe, ProgressRingComponent],
  templateUrl: './roadmap.page.html'
})
export class RoadmapPage {
  readonly curriculum = inject(CurriculumService);
  readonly progress = inject(ProgressService);
}
