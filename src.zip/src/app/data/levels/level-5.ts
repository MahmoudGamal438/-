import { Level } from '../../core/models/curriculum.model';
import { analogy, code, lesson, list, t, tip, warn } from '../helpers';

export const LEVEL_5: Level = {
  id: 'angular-fundamentals',
  number: 5,
  code: 'L5',
  title: 'Angular الاساسيات',
  titleEn: 'Angular Fundamentals',
  tagline: 'من ng new لحد تطبيق فيه صفحات وخدمات وطلبات HTTP.',
  color: '#dd0031',
  duration: '٢٨–٤٠ يوم',
  why: 'دي المرحلة الاساسية في المنصة: تفهم Angular الحديث Standalone مش نسخ قديمة.',
  beforeYouStart: [
    'JS و TS مريحين',
    'HTML/CSS كويسين',
    'Node و Angular CLI مثبتين',
    'فاهم Git بشكل مبدئي'
  ],
  goals: [
    'تنشئ مشروع Standalone.',
    'تبني Components و Routes.',
    'تستخدم Signals بثقة.',
    'تعمل Forms و Validation.',
    'تجيب بيانات بـ HttpClient.'
  ],
  skillsGained: [
    'Components',
    'Templates',
    'Signals',
    'Routing',
    'Services + DI',
    'Reactive Forms',
    'HttpClient'
  ],
  nextSkills: ['RxJS أعمق', 'Guards', 'Architecture'],
  tools: ['Angular CLI', 'Angular DevTools', 'VS Code Angular Language Service'],
  lessons: [
    lesson(
      'l5-1',
      'angular-mental-model',
      'Angular مش سحر: الموديل الذهني',
      'Angular Mental Model',
      24,
      'Component بيرسم، Service بيحفظ المنطق، Router بيبدل الصفحات.',
      ['ترسم المعمار على ورق.', 'تعرف Standalone.', 'تفهم CLI بيولد ايه.'],
      [
        analogy(
          'مطعم منظّم',
          'الـ Component هو السفرجية: شكل الطبق قدام العميل. الـ Service المطبخ. الـ Router قائمة الاقسام. الـ DI مدير المطعم اللي بيوصل الطلب للمكان الصح من غير ما كل واحد يعمل ثلاجة لوحده.'
        ),
        code(
          'bash',
          `npm install -g @angular/cli\nng new masar --routing --style=scss --ssr=false --standalone\ncd masar && ng serve`
        ),
        tip('نسخة حديثة', 'احنا بنشرح Angular 19+: Standalone، Signals، control flow الجديد @if @for.')
      ]
    ),
    lesson(
      'l5-2',
      'components-templates',
      'Components و Templates',
      'Components and Templates',
      28,
      'وحدة البناء: منطق + قالب + ستايل.',
      ['تعمل كومبوننت.', 'تمرر Input.', 'تطلع Output.'],
      [
        code(
          'typescript',
          `@Component({\n  selector: 'app-level-card',\n  standalone: true,\n  template: \`<article>\n    <h3>{{ level().title }}</h3>\n    <button (click)="open.emit(level().id)">ادخل</button>\n  </article>\`\n})\nexport class LevelCardComponent {\n  level = input.required<Level>();\n  open = output<string>();\n}`
        )
      ]
    ),
    lesson(
      'l5-3',
      'binding-directives',
      'Binding و Directives و Pipes',
      'Binding, Directives, Pipes',
      26,
      'القالب لغة visula للبيانات.',
      ['تعرف interpolation و property و event.', 'تستخدم @if @for.', 'تكتب pipe بسيطة.'],
      [
        code(
          'html',
          `@if (progress() >= 100) {\n  <p>المستوى اتسكر. عاش!</p>\n} @else {\n  <p>لسه {{ progress() }}%</p>\n}\n\n@for (lesson of lessons(); track lesson.id) {\n  <a [routerLink]="['/learn', lesson.slug]">{{ lesson.title }}</a>\n}`
        ),
        warn('ngIf القديم', 'هتشوفه في مشاريع قديمة. في الجديد استخدم @if و @for.')
      ]
    ),
    lesson(
      'l5-4',
      'services-di',
      'Services و Dependency Injection',
      'Services and DI',
      26,
      'منطق مشترك من غير تكرار.',
      ['تعمل خدمة providedIn root.', 'تحقنها بـ inject().', 'تسيب الكومبوننت نحيف.'],
      [
        code(
          'typescript',
          `@Injectable({ providedIn: 'root' })\nexport class ProgressService {\n  private readonly store = inject(StorageService);\n  percent(levelId: string): number {\n    return this.store.percent(levelId);\n  }\n}`
        ),
        t('لو لقيت الكومبوننت بقى بيحسب وبيخزن وبيرسم، اطلع الحساب والتخزين لخدمة.')
      ]
    ),
    lesson(
      'l5-5',
      'routing',
      'Routing: التطبيق بقى صفحات',
      'Routing',
      24,
      'مسارات واضحة، عناوين مفهومة، lazy لو احتجت.',
      ['تعرف Routes.', 'تمرر :id.', 'تستخدم routerLink.'],
      [
        code(
          'typescript',
          `export const routes: Routes = [\n  { path: '', loadComponent: () => import('./features/home/home.page').then(m => m.HomePage) },\n  { path: 'roadmap', loadComponent: () => import('./features/roadmap/roadmap.page').then(m => m.RoadmapPage) },\n  { path: 'learn/:levelId/:lessonSlug', loadComponent: () => import('./features/lesson/lesson.page').then(m => m.LessonPage) }\n];`
        )
      ]
    ),
    lesson(
      'l5-6',
      'forms',
      'Forms و Validation',
      'Forms',
      28,
      'Reactive Forms للتطبيقات الجدية.',
      ['تبني FormGroup.', 'تعمل validators.', 'تعرض رسائل عربي مفهومة.'],
      [
        code(
          'typescript',
          `this.form = this.fb.nonNullable.group({\n  email: ['', [Validators.required, Validators.email]],\n  password: ['', [Validators.required, Validators.minLength(8)]],\n});`
        )
      ]
    ),
    lesson(
      'l5-7',
      'http-client',
      'HttpClient و APIs',
      'HTTP Client',
      26,
      'البيانات الحقيقية.',
      ['تعمل GET typed.', 'تعالج الخطأ.', 'تفصل طبقة API.'],
      [
        code(
          'typescript',
          `getLessons(levelId: string) {\n  return this.http.get<Lesson[]>(\`/api/levels/\${levelId}/lessons\`);\n}`
        ),
        tip('في المنصة دي', 'المحتوى محلي عشان تتعلم من غير باك اند. بعدين نفس الخدمات تقدر تحولها لـ HTTP.')
      ]
    ),
    lesson(
      'l5-8',
      'signals',
      'Signals: حالة الواجهة الحديثة',
      'Signals',
      24,
      'بدل ما تلف في Change Detection يدوي، خلّي الاعتمادية واضحة.',
      ['تعمل signal.', 'تستخدم computed.', 'تحدث بـ update/set.'],
      [
        code(
          'typescript',
          `completed = signal<string[]>([]);\npercent = computed(() => {\n  const total = this.lessons().length || 1;\n  return Math.round((this.completed().length / total) * 100);\n});\nmark(id: string) {\n  this.completed.update(list => list.includes(id) ? list : [...list, id]);\n}`
        )
      ],
      {
        exercise: {
          id: 'l5-ex',
          title: 'كرت مستوى تفاعلي',
          difficulty: 'medium',
          brief: 'كومبوننت Standalone بياخد Level ويعرض النسبة ويزرار يكمل الدرس الحالي.',
          hints: ['input.required', 'computed', 'routerLink'],
          solution: 'LevelCard مع signals للنسبة و output للحدث.'
        }
      }
    )
  ],
  quiz: [
    {
      id: 'l5-q1',
      prompt: 'Service بنحقنها ليه؟',
      options: ['عشان الشكل', 'مشاركة منطق وحالة وطلبات من غير تكرار', 'بدل CSS', 'عشان Git'],
      answerIndex: 1,
      explanation: 'DI بتخلي الاعتماديات واضحة وقابلة للاختبار.'
    },
    {
      id: 'l5-q2',
      prompt: 'signal مناسب لامتى؟',
      options: ['ملفات النظام', 'حالة واجهة تتحدث ويتفرع منها قيم محسوبة', 'تثبيت Node', 'كتابة README'],
      answerIndex: 1,
      explanation: 'Signals نموذج حالة دقيق للكومبوننت والخدمات الخفيفة.'
    }
  ],
  projects: [
    {
      id: 'l5-p1',
      title: 'نسخة مصغرة من مسار',
      titleEn: 'Mini Masar',
      size: 'medium',
      levelId: 'angular-fundamentals',
      duration: 'اسبوع',
      summary: 'تطبيق دروس: قائمة مستويات، صفحة درس، تتبع تقدم محلي.',
      skills: ['Routing', 'Signals', 'Services', 'Standalone'],
      features: ['Roadmap', 'Lesson view', 'Progress %'],
      portfolioValue: 'اول مشروع Angular حقيقي في الـ GitHub.'
    }
  ]
};
