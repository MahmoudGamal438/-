export type BlockType =
  | 'text'
  | 'heading'
  | 'code'
  | 'tip'
  | 'warning'
  | 'analogy'
  | 'list'
  | 'steps'
  | 'playground'
  | 'compare';

export interface ContentBlock {
  type: BlockType;
  title?: string;
  body?: string;
  items?: string[];
  language?: 'html' | 'css' | 'javascript' | 'typescript' | 'bash' | 'json' | 'text';
  code?: string;
  playground?: {
    html?: string;
    css?: string;
    js?: string;
  };
  left?: string;
  right?: string;
  leftTitle?: string;
  rightTitle?: string;
}

export interface QuizQuestion {
  id: string;
  prompt: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface Exercise {
  id: string;
  title: string;
  difficulty: 'easy' | 'medium' | 'hard';
  brief: string;
  hints: string[];
  solution: string;
}

export interface Challenge {
  id: string;
  title: string;
  brief: string;
  goals: string[];
}

export interface Project {
  id: string;
  title: string;
  titleEn: string;
  size: 'mini' | 'medium' | 'capstone';
  levelId: string;
  duration: string;
  summary: string;
  skills: string[];
  features: string[];
  portfolioValue: string;
}

export interface Lesson {
  id: string;
  slug: string;
  title: string;
  titleEn: string;
  durationMin: number;
  summary: string;
  objectives: string[];
  blocks: ContentBlock[];
  exercise?: Exercise;
  challenge?: Challenge;
}

export interface Level {
  id: string;
  number: number;
  code: string;
  title: string;
  titleEn: string;
  tagline: string;
  color: string;
  duration: string;
  why: string;
  beforeYouStart: string[];
  goals: string[];
  skillsGained: string[];
  nextSkills: string[];
  tools: string[];
  lessons: Lesson[];
  quiz: QuizQuestion[];
  projects: Project[];
}

export interface LibraryItem {
  id: string;
  name: string;
  category: string;
  when: string;
  vs: string;
  how: string;
}

export interface AiTopic {
  id: string;
  title: string;
  summary: string;
  blocks: ContentBlock[];
}

export interface JobTopic {
  id: string;
  title: string;
  summary: string;
  blocks: ContentBlock[];
}
