import { JobTopic } from '../core/models/curriculum.model';
import { list, t } from './helpers';

export const JOB_TOPICS: JobTopic[] = [
  {
    id: 'stack-around',
    title: 'الستاك اللي حوالين Angular',
    summary: 'APIs، Auth، قواعد بيانات للمفهوم، نشر، Docker بحدود.',
    blocks: [
      t('فرونت اند من غير فهم الشبكة بيبقى رسام شاشات. اتعلم تقرأ Swagger، تفهم 401، وتفرق بين بيئة التطوير والإنتاج.'),
      list('حد أدنى', ['REST', 'JWT', 'CORS الفكرة', 'Build + static hosting', 'Dockerfile قراءة'])
    ]
  },
  {
    id: 'clean-code',
    title: 'Clean Code و Patterns',
    summary: 'أسماء، دوال صغيرة، طبقات.',
    blocks: [
      list('عمليًا', [
        'Smart containers / dump components',
        'Facade للخدمات المعقدة',
        'ما فيش God component',
        'Error paths أولًا'
      ])
    ]
  },
  {
    id: 'hiring-pack',
    title: 'حزمة التقديم',
    summary: 'CV، LinkedIn، GitHub، Portfolio.',
    blocks: [
      t('٣ مشاريع مش ١٠. كل مشروع: مشكلة، حل، صورة، لينك لايف لو قدر، قرارات تقنية.')
    ]
  },
  {
    id: 'task-playbook',
    title: 'تاسك الشركة',
    summary: 'هدوء، نطاق، تسليم.',
    blocks: [
      list('في أول ساعة', [
        'اقرأ المطلوب مرتين.',
        'اكتب افتراضاتك.',
        'حدد الـ MVP.',
        'ارسم المجلدات.',
        'ابدأ بالموديل والراوتس.'
      ])
    ]
  }
];
