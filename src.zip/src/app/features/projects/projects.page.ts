import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurriculumService } from '../../core/services/curriculum.service';

@Component({
  selector: 'app-projects-page',
  imports: [RouterLink],
  template: `
    <section class="page-head">
      <div>
        <p class="eyebrow">Build in public</p>
        <h1>مشاريع من Mini لحد شغل يشبه الشركات</h1>
        <p>كل مرحلة فيها تطبيق. الآخر محفظة تتناقش في المقابلة.</p>
      </div>
    </section>
    <div class="project-grid">
      @for (project of curriculum.allProjects(); track project.id) {
        <article class="project-card" [class.cap]="project.size === 'capstone'">
          <span class="pill">{{ project.size }}</span>
          <h2>{{ project.title }}</h2>
          <p class="en">{{ project.titleEn }}</p>
          <p>{{ project.summary }}</p>
          <p class="muted">{{ project.duration }}</p>
          <div class="chips">
            @for (skill of project.skills; track skill) {
              <span>{{ skill }}</span>
            }
          </div>
          <h3>الخصائص</h3>
          <ul class="check">
            @for (f of project.features; track f) {
              <li>{{ f }}</li>
            }
          </ul>
          <p><strong>قيمة الـ Portfolio:</strong> {{ project.portfolioValue }}</p>
          <a [routerLink]="['/levels', project.levelId]">المستوى المرتبط</a>
        </article>
      }
    </div>
  `
})
export class ProjectsPage {
  readonly curriculum = inject(CurriculumService);
}
