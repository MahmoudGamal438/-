import { Level } from '../../core/models/curriculum.model';
import { lesson, list, steps, t, tip } from '../helpers';

export const LEVEL_10: Level = {
  id: 'job-ready',
  number: 10,
  code: 'L10',
  title: 'من متعلم لـ Angular Developer جاهز للشغل',
  titleEn: 'Job Ready',
  tagline: 'بعد الكود: فريق، نشر، CV، مقابلة، وتاسك شركة.',
  color: '#f43f5e',
  duration: '١٤–٢١ يوم',
  why: 'ناس كتير بتوصل هنا وتقف. المرحلة دي بتترجم المهارة لفرصة.',
  beforeYouStart: ['عندك مشروعين Angular', 'فاهم Git', 'تقدر تشرح قراراتك'],
  goals: [
    'تعرف تتعامل مع API و Auth في سياق شغل.',
    'تنشر نسخة من مشروع.',
    'تبني CV و LinkedIn و GitHub.',
    'تحل تاسك تقني بهدوء.'
  ],
  skillsGained: [
    'Deployment',
    'Team Git',
    'Code review',
    'Interview prep',
    'Technical tasks',
    'Portfolio narrative'
  ],
  nextSkills: ['Backend basics أعمق', 'Full stack later'],
  tools: ['GitHub', 'LinkedIn', 'أي Hosting للـ Front-End', 'Docker بدائي'],
  lessons: [
    lesson(
      'l10-1',
      'beyond-angular',
      'بعد Angular فيه ايه؟',
      'Beyond Angular',
      20,
      'خريطة ما بعد الإطار.',
      ['تعرف الحد الادنى من Backend.', 'تفهم Deployment.', 'تعرف Docker للفكرة مش للاحتراف.'],
      [
        list('حد ادنى لسوق Front-End', [
          'REST و JSON.',
          'JWT بشكل عملي.',
          'SQL فكرة الجداول والعلاقات.',
          'CI بسيطة.',
          'بيئات dev/stage/prod.'
        ]),
        t('مش مطلوب تبقى DevOps. مطلوب تفهم التطبيق بيطلع من جهازك للسيرفر ازاي، وملف البيئة مش بيتترفع.')
      ]
    ),
    lesson(
      'l10-2',
      'team-git',
      'Git في فريق و Code Review',
      'Team Git',
      18,
      'Branch، PR، نقاش مهذب.',
      ['تعمل فروع.', 'تكتب وصف PR.', 'ترد على كومنت من غير دفاع زيادة.'],
      [
        steps('PR محترم', [
          'عنوان واضح.',
          'ليه التغيير.',
          'ازاي يتختبر.',
          'سكرين لو UI.',
          'مقاس صغير.'
        ])
      ]
    ),
    lesson(
      'l10-3',
      'cv-linkedin',
      'CV و LinkedIn و GitHub',
      'Personal Brand',
      20,
      'السيرة قصص مشاريع مش قائمة كورسات.',
      ['تكتب مشروع بنتيجة.', 'تظبط pinned repos.', 'تخلي LinkedIn عربي/انجليزي واضح.'],
      [
        tip(
          'سطر مشروع',
          'وحش: "عملت موقع Angular". احسن: "بنيت منصة تعلم RTL فيها تتبع تقدم محلي و١١ مستوى وكود منظم core/features".'
        )
      ]
    ),
    lesson(
      'l10-4',
      'interviews-tasks',
      'المقابلات والتاسكات',
      'Interviews and Tasks',
      24,
      'المقابلة محادثة تصميم، والتاسك اختبار هدوء.',
      ['تشرح Component lifecycle بأسلوبك.', 'تكسر التاسك لساعات.', 'تسلم مع README.'],
      [
        list('اسئلة اتوقعها', [
          'Change detection vs Signals',
          'Smart vs presentational',
          'Memory leaks في اشتراكات',
          'Lazy loading ليه',
          'ازاي تؤمن توكن',
          'فرق Template driven و Reactive forms'
        ]),
        t('التاسك: حدد الوقت، اعمل خطة، سلم حاجة ناقصة واضحة احسن من حاجة كبيرة مكسورة. اكتب اللي معملتهوش.')
      ]
    )
  ],
  quiz: [
    {
      id: 'l10-q1',
      prompt: 'احسن وصف لمشروع في الـ CV؟',
      options: [
        'استخدمت Angular',
        'المشكلة، الحل، التقنيات، ونتيجة واضحة',
        'لستة كورسات',
        'عدد سطور الكود'
      ],
      answerIndex: 1,
      explanation: 'المقابل عايز اثر وقرارات.'
    }
  ],
  projects: [
    {
      id: 'l10-p1',
      title: 'تاسك شركة محاكى',
      titleEn: 'Simulated Company Task',
      size: 'capstone',
      levelId: 'job-ready',
      duration: '٤٨ ساعة مقصوصة',
      summary: 'اطلب من نفسك تبني لوحة مهام بفلاتر خلال يومين، بـ README وملاحظات قرار.',
      skills: ['Timeboxing', 'Delivery', 'Docs'],
      features: ['CRUD', 'Filter', 'README', 'Known issues'],
      portfolioValue: 'اقرب محاكاة لمهمة توظيف.'
    }
  ]
};
